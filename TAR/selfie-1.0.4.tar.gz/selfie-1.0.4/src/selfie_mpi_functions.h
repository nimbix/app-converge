#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <cstring>
#include <execinfo.h>
#include <dlfcn.h>
#include <cstdarg>
#include <fenv.h>

#pragma STDC FENV_ACCESS ON

typedef void (*function_type)(...);


/// \brief Total number of MPI functions
#define N_MPI_FUNCTIONS 295

/// \brief Return a string containing name of functions
/// \param[in] i Index
/// \return   Return a string containing name of functions
///
char *selfie_get_mpi_function_name(int i)
{
   char const *mpi_functions_name[] = {
      "MPI_Wtick",
      "MPI_Wtime",
      "MPI_Abort",
      "MPI_Accumulate",
      "MPI_Add_error_class",
      "MPI_Add_error_code",
      "MPI_Add_error_string",
      "MPI_Address",
      "MPI_Allgather",
      "MPI_Allgatherv",
      "MPI_Alloc_mem",
      "MPI_Allreduce",
      "MPI_Alltoall",
      "MPI_Alltoallv",
      "MPI_Alltoallw",
      "MPI_Attr_delete",
      "MPI_Attr_get",
      "MPI_Attr_put",
      "MPI_Barrier",
      "MPI_Bcast",
      "MPI_Bsend",
      "MPI_Bsend_init",
      "MPI_Buffer_attach",
      "MPI_Buffer_detach",
      "MPI_Cancel",
      "MPI_Cart_coords",
      "MPI_Cart_create",
      "MPI_Cartdim_get",
      "MPI_Cart_get",
      "MPI_Cart_map",
      "MPI_Cart_rank",
      "MPI_Cart_shift",
      "MPI_Cart_sub",
      "MPI_Close_port",
      "MPI_Comm_accept",
      "MPI_Comm_call_errhandler",
      "MPI_Comm_compare",
      "MPI_Comm_connect",
      "MPI_Comm_create_errhandler",
      "MPI_Comm_create_group",
      "MPI_Comm_create_keyval",
      "MPI_Comm_create",
      "MPI_Comm_delete_attr",
      "MPI_Comm_disconnect",
      "MPI_Comm_dup",
      "MPI_Comm_dup_with_info",
      "MPI_Comm_free_keyval",
      "MPI_Comm_free",
      "MPI_Comm_get_attr",
      "MPI_Comm_get_errhandler",
      "MPI_Comm_get_info",
      "MPI_Comm_get_name",
      "MPI_Comm_get_parent",
      "MPI_Comm_group",
      "MPI_Comm_idup",
      "MPI_Comm_join",
      "MPI_Comm_rank",
      "MPI_Comm_remote_group",
      "MPI_Comm_remote_size",
      "MPI_Comm_set_attr",
      "MPI_Comm_set_errhandler",
      "MPI_Comm_set_info",
      "MPI_Comm_set_name",
      "MPI_Comm_size",
      "MPI_Comm_spawn",
      "MPI_Comm_spawn_multiple",
      "MPI_Comm_split",
      "MPI_Comm_split_type",
      "MPI_Comm_test_inter",
      "MPI_Compare_and_swap",
      "MPI_Dims_create",
      "MPI_Dist_graph_create_adjacent",
      "MPI_Dist_graph_create",
      "MPI_Dist_graph_neighbors_count",
      "MPI_Dist_graph_neighbors",
      "MPI_Errhandler_create",
      "MPI_Errhandler_free",
      "MPI_Errhandler_get",
      "MPI_Errhandler_set",
      "MPI_Error_class",
      "MPI_Error_string",
      "MPI_Exscan",
      "MPI_Fetch_and_op",
      "MPI_Finalized",
      "MPI_Finalize",
      "MPI_Free_mem",
      "MPI_Gather",
      "MPI_Gatherv",
      "MPI_Get_accumulate",
      "MPI_Get_address",
      "MPI_Get_count",
      "MPI_Get_elements",
      "MPI_Get_elements_x",
      "MPI_Get_library_version",
      "MPI_Get_processor_name",
      "MPI_Get_version",
      "MPI_Get",
      "MPI_Graph_create",
      "MPI_Graphdims_get",
      "MPI_Graph_get",
      "MPI_Graph_map",
      "MPI_Graph_neighbors_count",
      "MPI_Graph_neighbors",
      "MPI_Grequest_complete",
      "MPI_Grequest_start",
      "MPI_Group_compare",
      "MPI_Group_difference",
      "MPI_Group_excl",
      "MPI_Group_free",
      "MPI_Group_incl",
      "MPI_Group_intersection",
      "MPI_Group_range_excl",
      "MPI_Group_range_incl",
      "MPI_Group_rank",
      "MPI_Group_size",
      "MPI_Group_translate_ranks",
      "MPI_Group_union",
      "MPI_Iallgather",
      "MPI_Iallgatherv",
      "MPI_Iallreduce",
      "MPI_Ialltoall",
      "MPI_Ialltoallv",
      "MPI_Ialltoallw",
      "MPI_Ibarrier",
      "MPI_Ibcast",
      "MPI_Ibsend",
      "MPI_Iexscan",
      "MPI_Igather",
      "MPI_Igatherv",
      "MPI_Improbe",
      "MPI_Imrecv",
      "MPI_Ineighbor_allgather",
      "MPI_Ineighbor_allgatherv",
      "MPI_Ineighbor_alltoall",
      "MPI_Ineighbor_alltoallv",
      "MPI_Ineighbor_alltoallw",
      "MPI_Info_create",
      "MPI_Info_delete",
      "MPI_Info_dup",
      "MPI_Info_free",
      "MPI_Info_get",
      "MPI_Info_get_nkeys",
      "MPI_Info_get_nthkey",
      "MPI_Info_get_valuelen",
      "MPI_Info_set",
      "MPI_Initialized",
      "MPI_Init",
      "MPI_Init_thread",
      "MPI_Intercomm_create",
      "MPI_Intercomm_merge",
      "MPI_Irecv",
      "MPI_Ireduce",
      "MPI_Ireduce_scatter_block",
      "MPI_Ireduce_scatter",
      "MPI_Irsend",
      "MPI_Iscan",
      "MPI_Iscatter",
      "MPI_Iscatterv",
      "MPI_Isend",
      "MPI_Issend",
      "MPI_Is_thread_main",
      "MPI_Keyval_create",
      "MPI_Keyval_free",
      "MPI_Lookup_name",
      "MPI_Mprobe",
      "MPI_Mrecv",
      "MPI_Neighbor_allgather",
      "MPI_Neighbor_allgatherv",
      "MPI_Neighbor_alltoall",
      "MPI_Neighbor_alltoallv",
      "MPI_Neighbor_alltoallw",
      "MPI_Op_commutative",
      "MPI_Op_create",
      "MPI_Open_port",
      "MPI_Op_free",
      "MPI_Pack",
      "MPI_Pack_external",
      "MPI_Pack_external_size",
      "MPI_Pack_size",
      "MPI_Probe",
      "MPI_Publish_name",
      "MPI_Put",
      "MPI_Query_thread",
      "MPI_Raccumulate",
      "MPI_Recv_init",
      "MPI_Recv",
      "MPI_Reduce",
      "MPI_Reduce_local",
      "MPI_Reduce_scatter_block",
      "MPI_Reduce_scatter",
      "MPI_Register_datarep",
      "MPI_Request_free",
      "MPI_Request_get_status",
      "MPI_Rget_accumulate",
      "MPI_Rget",
      "MPI_Rput",
      "MPI_Rsend",
      "MPI_Rsend_init",
      "MPI_Scan",
      "MPI_Scatter",
      "MPI_Scatterv",
      "MPI_Send",
      "MPI_Send_init",
      "MPI_Sendrecv",
      "MPI_Sendrecv_replace",
      "MPI_Ssend",
      "MPI_Ssend_init",
      "MPI_Startall",
      "MPI_Start",
      "MPI_Status_set_cancelled",
      "MPI_Status_set_elements",
      "MPI_Status_set_elements_x",
      "MPI_Topo_test",
      "MPI_Type_commit",
      "MPI_Type_contiguous",
      "MPI_Type_create_darray",
      "MPI_Type_create_f90_complex",
      "MPI_Type_create_f90_integer",
      "MPI_Type_create_f90_real",
      "MPI_Type_create_hindexed_block",
      "MPI_Type_create_hindexed",
      "MPI_Type_create_hvector",
      "MPI_Type_create_indexed_block",
      "MPI_Type_create_keyval",
      "MPI_Type_create_resized",
      "MPI_Type_create_struct",
      "MPI_Type_create_subarray",
      "MPI_Type_delete_attr",
      "MPI_Type_dup",
      "MPI_Type_extent",
      "MPI_Type_free_keyval",
      "MPI_Type_free",
      "MPI_Type_get_attr",
      "MPI_Type_get_contents",
      "MPI_Type_get_envelope",
      "MPI_Type_get_extent",
      "MPI_Type_get_extent_x",
      "MPI_Type_get_name",
      "MPI_Type_get_true_extent",
      "MPI_Type_get_true_extent_x",
      "MPI_Type_hindexed",
      "MPI_Type_hvector",
      "MPI_Type_indexed",
      "MPI_Type_lb",
      "MPI_Type_match_size",
      "MPI_Type_set_attr",
      "MPI_Type_set_name",
      "MPI_Type_size",
      "MPI_Type_size_x",
      "MPI_Type_struct",
      "MPI_Type_ub",
      "MPI_Type_vector",
      "MPI_Unpack",
      "MPI_Unpack_external",
      "MPI_Unpublish_name",
      "MPI_Waitall",
      "MPI_Waitany",
      "MPI_Wait",
      "MPI_Waitsome",
      "MPI_Win_allocate",
      "MPI_Win_allocate_shared",
      "MPI_Win_attach",
      "MPI_Win_call_errhandler",
      "MPI_Win_complete",
      "MPI_Win_create_dynamic",
      "MPI_Win_create_errhandler",
      "MPI_Win_create_keyval",
      "MPI_Win_create",
      "MPI_Win_delete_attr",
      "MPI_Win_detach",
      "MPI_Win_fence",
      "MPI_Win_flush_all",
      "MPI_Win_flush",
      "MPI_Win_flush_local_all",
      "MPI_Win_flush_local",
      "MPI_Win_free_keyval",
      "MPI_Win_free",
      "MPI_Win_get_attr",
      "MPI_Win_get_errhandler",
      "MPI_Win_get_group",
      "MPI_Win_get_info",
      "MPI_Win_get_name",
      "MPI_Win_lock_all",
      "MPI_Win_lock",
      "MPI_Win_post",
      "MPI_Win_set_attr",
      "MPI_Win_set_errhandler",
      "MPI_Win_set_info",
      "MPI_Win_set_name",
      "MPI_Win_shared_query",
      "MPI_Win_start",
      "MPI_Win_sync",
      "MPI_Win_unlock_all",
      "MPI_Win_unlock",
      "MPI_Win_wait",
      "PMPI_Wtick",
      "PMPI_Wtime",
      "PMPI_Abort",
      "PMPI_Accumulate",
      "PMPI_Add_error_class",
      "PMPI_Add_error_code",
      "PMPI_Add_error_string",
      "PMPI_Address",
      "PMPI_Allgather",
      "PMPI_Allgatherv",
      "PMPI_Alloc_mem",
      "PMPI_Allreduce",
      "PMPI_Alltoall",
      "PMPI_Alltoallv",
      "PMPI_Alltoallw",
      "PMPI_Attr_delete",
      "PMPI_Attr_get",
      "PMPI_Attr_put",
      "PMPI_Barrier",
      "PMPI_Bcast",
      "PMPI_Bsend",
      "PMPI_Bsend_init",
      "PMPI_Buffer_attach",
      "PMPI_Buffer_detach",
      "PMPI_Cancel",
      "PMPI_Cart_coords",
      "PMPI_Cart_create",
      "PMPI_Cartdim_get",
      "PMPI_Cart_get",
      "PMPI_Cart_map",
      "PMPI_Cart_rank",
      "PMPI_Cart_shift",
      "PMPI_Cart_sub",
      "PMPI_Close_port",
      "PMPI_Comm_accept",
      "PMPI_Comm_call_errhandler",
      "PMPI_Comm_compare",
      "PMPI_Comm_connect",
      "PMPI_Comm_create_errhandler",
      "PMPI_Comm_create_group",
      "PMPI_Comm_create_keyval",
      "PMPI_Comm_create",
      "PMPI_Comm_delete_attr",
      "PMPI_Comm_disconnect",
      "PMPI_Comm_dup",
      "PMPI_Comm_dup_with_info",
      "PMPI_Comm_free_keyval",
      "PMPI_Comm_free",
      "PMPI_Comm_get_attr",
      "PMPI_Comm_get_errhandler",
      "PMPI_Comm_get_info",
      "PMPI_Comm_get_name",
      "PMPI_Comm_get_parent",
      "PMPI_Comm_group",
      "PMPI_Comm_idup",
      "PMPI_Comm_join",
      "PMPI_Comm_rank",
      "PMPI_Comm_remote_group",
      "PMPI_Comm_remote_size",
      "PMPI_Comm_set_attr",
      "PMPI_Comm_set_errhandler",
      "PMPI_Comm_set_info",
      "PMPI_Comm_set_name",
      "PMPI_Comm_size",
      "PMPI_Comm_spawn",
      "PMPI_Comm_spawn_multiple",
      "PMPI_Comm_split",
      "PMPI_Comm_split_type",
      "PMPI_Comm_test_inter",
      "PMPI_Compare_and_swap",
      "PMPI_Dims_create",
      "PMPI_Dist_graph_create_adjacent",
      "PMPI_Dist_graph_create",
      "PMPI_Dist_graph_neighbors_count",
      "PMPI_Dist_graph_neighbors",
      "PMPI_Errhandler_create",
      "PMPI_Errhandler_free",
      "PMPI_Errhandler_get",
      "PMPI_Errhandler_set",
      "PMPI_Error_class",
      "PMPI_Error_string",
      "PMPI_Exscan",
      "PMPI_Fetch_and_op",
      "PMPI_Finalized",
      "PMPI_Finalize",
      "PMPI_Free_mem",
      "PMPI_Gather",
      "PMPI_Gatherv",
      "PMPI_Get_accumulate",
      "PMPI_Get_address",
      "PMPI_Get_count",
      "PMPI_Get_elements",
      "PMPI_Get_elements_x",
      "PMPI_Get_library_version",
      "PMPI_Get_processor_name",
      "PMPI_Get_version",
      "PMPI_Get",
      "PMPI_Graph_create",
      "PMPI_Graphdims_get",
      "PMPI_Graph_get",
      "PMPI_Graph_map",
      "PMPI_Graph_neighbors_count",
      "PMPI_Graph_neighbors",
      "PMPI_Grequest_complete",
      "PMPI_Grequest_start",
      "PMPI_Group_compare",
      "PMPI_Group_difference",
      "PMPI_Group_excl",
      "PMPI_Group_free",
      "PMPI_Group_incl",
      "PMPI_Group_intersection",
      "PMPI_Group_range_excl",
      "PMPI_Group_range_incl",
      "PMPI_Group_rank",
      "PMPI_Group_size",
      "PMPI_Group_translate_ranks",
      "PMPI_Group_union",
      "PMPI_Iallgather",
      "PMPI_Iallgatherv",
      "PMPI_Iallreduce",
      "PMPI_Ialltoall",
      "PMPI_Ialltoallv",
      "PMPI_Ialltoallw",
      "PMPI_Ibarrier",
      "PMPI_Ibcast",
      "PMPI_Ibsend",
      "PMPI_Iexscan",
      "PMPI_Igather",
      "PMPI_Igatherv",
      "PMPI_Improbe",
      "PMPI_Imrecv",
      "PMPI_Ineighbor_allgather",
      "PMPI_Ineighbor_allgatherv",
      "PMPI_Ineighbor_alltoall",
      "PMPI_Ineighbor_alltoallv",
      "PMPI_Ineighbor_alltoallw",
      "PMPI_Info_create",
      "PMPI_Info_delete",
      "PMPI_Info_dup",
      "PMPI_Info_free",
      "PMPI_Info_get",
      "PMPI_Info_get_nkeys",
      "PMPI_Info_get_nthkey",
      "PMPI_Info_get_valuelen",
      "PMPI_Info_set",
      "PMPI_Initialized",
      "PMPI_Init",
      "PMPI_Init_thread",
      "PMPI_Intercomm_create",
      "PMPI_Intercomm_merge",
      "PMPI_Irecv",
      "PMPI_Ireduce",
      "PMPI_Ireduce_scatter_block",
      "PMPI_Ireduce_scatter",
      "PMPI_Irsend",
      "PMPI_Iscan",
      "PMPI_Iscatter",
      "PMPI_Iscatterv",
      "PMPI_Isend",
      "PMPI_Issend",
      "PMPI_Is_thread_main",
      "PMPI_Keyval_create",
      "PMPI_Keyval_free",
      "PMPI_Lookup_name",
      "PMPI_Mprobe",
      "PMPI_Mrecv",
      "PMPI_Neighbor_allgather",
      "PMPI_Neighbor_allgatherv",
      "PMPI_Neighbor_alltoall",
      "PMPI_Neighbor_alltoallv",
      "PMPI_Neighbor_alltoallw",
      "PMPI_Op_commutative",
      "PMPI_Op_create",
      "PMPI_Open_port",
      "PMPI_Op_free",
      "PMPI_Pack",
      "PMPI_Pack_external",
      "PMPI_Pack_external_size",
      "PMPI_Pack_size",
      "PMPI_Probe",
      "PMPI_Publish_name",
      "PMPI_Put",
      "PMPI_Query_thread",
      "PMPI_Raccumulate",
      "PMPI_Recv_init",
      "PMPI_Recv",
      "PMPI_Reduce",
      "PMPI_Reduce_local",
      "PMPI_Reduce_scatter_block",
      "PMPI_Reduce_scatter",
      "PMPI_Register_datarep",
      "PMPI_Request_free",
      "PMPI_Request_get_status",
      "PMPI_Rget_accumulate",
      "PMPI_Rget",
      "PMPI_Rput",
      "PMPI_Rsend",
      "PMPI_Rsend_init",
      "PMPI_Scan",
      "PMPI_Scatter",
      "PMPI_Scatterv",
      "PMPI_Send",
      "PMPI_Send_init",
      "PMPI_Sendrecv",
      "PMPI_Sendrecv_replace",
      "PMPI_Ssend",
      "PMPI_Ssend_init",
      "PMPI_Startall",
      "PMPI_Start",
      "PMPI_Status_set_cancelled",
      "PMPI_Status_set_elements",
      "PMPI_Status_set_elements_x",
      "PMPI_Topo_test",
      "PMPI_Type_commit",
      "PMPI_Type_contiguous",
      "PMPI_Type_create_darray",
      "PMPI_Type_create_f90_complex",
      "PMPI_Type_create_f90_integer",
      "PMPI_Type_create_f90_real",
      "PMPI_Type_create_hindexed_block",
      "PMPI_Type_create_hindexed",
      "PMPI_Type_create_hvector",
      "PMPI_Type_create_indexed_block",
      "PMPI_Type_create_keyval",
      "PMPI_Type_create_resized",
      "PMPI_Type_create_struct",
      "PMPI_Type_create_subarray",
      "PMPI_Type_delete_attr",
      "PMPI_Type_dup",
      "PMPI_Type_extent",
      "PMPI_Type_free_keyval",
      "PMPI_Type_free",
      "PMPI_Type_get_attr",
      "PMPI_Type_get_contents",
      "PMPI_Type_get_envelope",
      "PMPI_Type_get_extent",
      "PMPI_Type_get_extent_x",
      "PMPI_Type_get_name",
      "PMPI_Type_get_true_extent",
      "PMPI_Type_get_true_extent_x",
      "PMPI_Type_hindexed",
      "PMPI_Type_hvector",
      "PMPI_Type_indexed",
      "PMPI_Type_lb",
      "PMPI_Type_match_size",
      "PMPI_Type_set_attr",
      "PMPI_Type_set_name",
      "PMPI_Type_size",
      "PMPI_Type_size_x",
      "PMPI_Type_struct",
      "PMPI_Type_ub",
      "PMPI_Type_vector",
      "PMPI_Unpack",
      "PMPI_Unpack_external",
      "PMPI_Unpublish_name",
      "PMPI_Waitall",
      "PMPI_Waitany",
      "PMPI_Wait",
      "PMPI_Waitsome",
      "PMPI_Win_allocate",
      "PMPI_Win_allocate_shared",
      "PMPI_Win_attach",
      "PMPI_Win_call_errhandler",
      "PMPI_Win_complete",
      "PMPI_Win_create_dynamic",
      "PMPI_Win_create_errhandler",
      "PMPI_Win_create_keyval",
      "PMPI_Win_create",
      "PMPI_Win_delete_attr",
      "PMPI_Win_detach",
      "PMPI_Win_fence",
      "PMPI_Win_flush_all",
      "PMPI_Win_flush",
      "PMPI_Win_flush_local_all",
      "PMPI_Win_flush_local",
      "PMPI_Win_free_keyval",
      "PMPI_Win_free",
      "PMPI_Win_get_attr",
      "PMPI_Win_get_errhandler",
      "PMPI_Win_get_group",
      "PMPI_Win_get_info",
      "PMPI_Win_get_name",
      "PMPI_Win_lock_all",
      "PMPI_Win_lock",
      "PMPI_Win_post",
      "PMPI_Win_set_attr",
      "PMPI_Win_set_errhandler",
      "PMPI_Win_set_info",
      "PMPI_Win_set_name",
      "PMPI_Win_shared_query",
      "PMPI_Win_start",
      "PMPI_Win_sync",
      "PMPI_Win_unlock_all",
      "PMPI_Win_unlock",
      "PMPI_Win_wait",
      NULL
   };
   return strdup(mpi_functions_name[i]);
};

/// \brief Array of pointers of functions
function_type selfie_mpi_orig_pointer_functions[295] = {NULL};

/// \brief Array of pointers of functions
function_type *selfie_mpi_pointer_functions = selfie_mpi_orig_pointer_functions;


extern "C" {


#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Wtick
///
/// \param ...
/// \return double
///
/// \details
///

double MPI_Wtick(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[0];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Wtick");
    }

    selfie_mpi_global_data[0].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[0].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Wtick
///
/// \param ...
/// \return double
///
/// \details
///

double PMPI_Wtick(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[0];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Wtick");
    }

    selfie_mpi_global_data[0].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[0].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Wtime
///
/// \param ...
/// \return double
///
/// \details
///

double MPI_Wtime(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[1];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Wtime");
    }

    selfie_mpi_global_data[1].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[1].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Wtime
///
/// \param ...
/// \return double
///
/// \details
///

double PMPI_Wtime(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[1];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Wtime");
    }

    selfie_mpi_global_data[1].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[1].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Abort
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Abort(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[2];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Abort");
    }

    selfie_mpi_global_data[2].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[2].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Abort
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Abort(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[2];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Abort");
    }

    selfie_mpi_global_data[2].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[2].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Accumulate
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Accumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[3];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Accumulate");
    }

    selfie_mpi_global_data[3].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[3].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Accumulate
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Accumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[3];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Accumulate");
    }

    selfie_mpi_global_data[3].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[3].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Add_error_class
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Add_error_class(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[4];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Add_error_class");
    }

    selfie_mpi_global_data[4].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[4].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Add_error_class
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Add_error_class(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[4];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Add_error_class");
    }

    selfie_mpi_global_data[4].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[4].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Add_error_code
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Add_error_code(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[5];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Add_error_code");
    }

    selfie_mpi_global_data[5].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[5].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Add_error_code
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Add_error_code(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[5];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Add_error_code");
    }

    selfie_mpi_global_data[5].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[5].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Add_error_string
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Add_error_string(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[6];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Add_error_string");
    }

    selfie_mpi_global_data[6].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[6].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Add_error_string
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Add_error_string(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[6];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Add_error_string");
    }

    selfie_mpi_global_data[6].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[6].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Address
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Address(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[7];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Address");
    }

    selfie_mpi_global_data[7].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[7].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Address
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Address(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[7];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Address");
    }

    selfie_mpi_global_data[7].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[7].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Allgather
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Allgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[8];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Allgather");
    }

    selfie_mpi_global_data[8].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[8].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Allgather
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Allgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[8];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Allgather");
    }

    selfie_mpi_global_data[8].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[8].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Allgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Allgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[9];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Allgatherv");
    }

    selfie_mpi_global_data[9].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[9].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Allgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Allgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[9];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Allgatherv");
    }

    selfie_mpi_global_data[9].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[9].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Alloc_mem
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Alloc_mem(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[10];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alloc_mem");
    }

    selfie_mpi_global_data[10].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[10].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Alloc_mem
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Alloc_mem(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[10];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alloc_mem");
    }

    selfie_mpi_global_data[10].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[10].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Allreduce
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Allreduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[11];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Allreduce");
    }

    selfie_mpi_global_data[11].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[11].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Allreduce
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Allreduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[11];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Allreduce");
    }

    selfie_mpi_global_data[11].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[11].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Alltoall
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Alltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[12];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alltoall");
    }

    selfie_mpi_global_data[12].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[12].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Alltoall
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Alltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[12];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alltoall");
    }

    selfie_mpi_global_data[12].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[12].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Alltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Alltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[13];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alltoallv");
    }

    selfie_mpi_global_data[13].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[13].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Alltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Alltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[13];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alltoallv");
    }

    selfie_mpi_global_data[13].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[13].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Alltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Alltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[14];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alltoallw");
    }

    selfie_mpi_global_data[14].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[14].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Alltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Alltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[14];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Alltoallw");
    }

    selfie_mpi_global_data[14].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[14].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Attr_delete
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Attr_delete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[15];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Attr_delete");
    }

    selfie_mpi_global_data[15].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[15].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Attr_delete
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Attr_delete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[15];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Attr_delete");
    }

    selfie_mpi_global_data[15].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[15].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Attr_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Attr_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[16];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Attr_get");
    }

    selfie_mpi_global_data[16].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[16].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Attr_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Attr_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[16];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Attr_get");
    }

    selfie_mpi_global_data[16].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[16].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Attr_put
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Attr_put(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[17];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Attr_put");
    }

    selfie_mpi_global_data[17].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[17].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Attr_put
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Attr_put(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[17];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Attr_put");
    }

    selfie_mpi_global_data[17].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[17].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Barrier
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Barrier(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[18];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Barrier");
    }

    selfie_mpi_global_data[18].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[18].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Barrier
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Barrier(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[18];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Barrier");
    }

    selfie_mpi_global_data[18].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[18].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Bcast
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Bcast(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[19];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Bcast");
    }

    selfie_mpi_global_data[19].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[19].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Bcast
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Bcast(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[19];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Bcast");
    }

    selfie_mpi_global_data[19].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[19].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Bsend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Bsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[20];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Bsend");
    }

    selfie_mpi_global_data[20].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[20].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Bsend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Bsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[20];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Bsend");
    }

    selfie_mpi_global_data[20].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[20].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Bsend_init
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Bsend_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[21];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Bsend_init");
    }

    selfie_mpi_global_data[21].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[21].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Bsend_init
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Bsend_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[21];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Bsend_init");
    }

    selfie_mpi_global_data[21].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[21].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Buffer_attach
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Buffer_attach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[22];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Buffer_attach");
    }

    selfie_mpi_global_data[22].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[22].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Buffer_attach
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Buffer_attach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[22];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Buffer_attach");
    }

    selfie_mpi_global_data[22].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[22].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Buffer_detach
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Buffer_detach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[23];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Buffer_detach");
    }

    selfie_mpi_global_data[23].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[23].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Buffer_detach
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Buffer_detach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[23];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Buffer_detach");
    }

    selfie_mpi_global_data[23].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[23].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cancel
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cancel(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[24];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cancel");
    }

    selfie_mpi_global_data[24].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[24].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cancel
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cancel(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[24];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cancel");
    }

    selfie_mpi_global_data[24].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[24].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_coords
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_coords(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[25];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_coords");
    }

    selfie_mpi_global_data[25].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[25].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_coords
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_coords(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[25];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_coords");
    }

    selfie_mpi_global_data[25].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[25].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[26];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_create");
    }

    selfie_mpi_global_data[26].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[26].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[26];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_create");
    }

    selfie_mpi_global_data[26].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[26].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cartdim_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cartdim_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[27];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cartdim_get");
    }

    selfie_mpi_global_data[27].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[27].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cartdim_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cartdim_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[27];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cartdim_get");
    }

    selfie_mpi_global_data[27].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[27].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[28];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_get");
    }

    selfie_mpi_global_data[28].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[28].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[28];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_get");
    }

    selfie_mpi_global_data[28].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[28].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_map
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_map(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[29];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_map");
    }

    selfie_mpi_global_data[29].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[29].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_map
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_map(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[29];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_map");
    }

    selfie_mpi_global_data[29].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[29].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_rank
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_rank(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[30];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_rank");
    }

    selfie_mpi_global_data[30].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[30].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_rank
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_rank(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[30];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_rank");
    }

    selfie_mpi_global_data[30].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[30].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_shift
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_shift(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[31];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_shift");
    }

    selfie_mpi_global_data[31].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[31].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_shift
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_shift(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[31];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_shift");
    }

    selfie_mpi_global_data[31].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[31].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Cart_sub
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Cart_sub(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[32];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_sub");
    }

    selfie_mpi_global_data[32].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[32].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Cart_sub
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Cart_sub(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[32];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Cart_sub");
    }

    selfie_mpi_global_data[32].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[32].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Close_port
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Close_port(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[33];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Close_port");
    }

    selfie_mpi_global_data[33].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[33].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Close_port
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Close_port(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[33];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Close_port");
    }

    selfie_mpi_global_data[33].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[33].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_accept
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_accept(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[34];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_accept");
    }

    selfie_mpi_global_data[34].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[34].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_accept
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_accept(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[34];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_accept");
    }

    selfie_mpi_global_data[34].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[34].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_call_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_call_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[35];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_call_errhandler");
    }

    selfie_mpi_global_data[35].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[35].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_call_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_call_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[35];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_call_errhandler");
    }

    selfie_mpi_global_data[35].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[35].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_compare
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_compare(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[36];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_compare");
    }

    selfie_mpi_global_data[36].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[36].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_compare
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_compare(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[36];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_compare");
    }

    selfie_mpi_global_data[36].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[36].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_connect
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_connect(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[37];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_connect");
    }

    selfie_mpi_global_data[37].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[37].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_connect
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_connect(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[37];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_connect");
    }

    selfie_mpi_global_data[37].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[37].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_create_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_create_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[38];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create_errhandler");
    }

    selfie_mpi_global_data[38].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[38].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_create_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_create_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[38];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create_errhandler");
    }

    selfie_mpi_global_data[38].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[38].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_create_group
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_create_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[39];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create_group");
    }

    selfie_mpi_global_data[39].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[39].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_create_group
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_create_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[39];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create_group");
    }

    selfie_mpi_global_data[39].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[39].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_create_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_create_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[40];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create_keyval");
    }

    selfie_mpi_global_data[40].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[40].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_create_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_create_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[40];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create_keyval");
    }

    selfie_mpi_global_data[40].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[40].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[41];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create");
    }

    selfie_mpi_global_data[41].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[41].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[41];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_create");
    }

    selfie_mpi_global_data[41].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[41].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_delete_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_delete_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[42];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_delete_attr");
    }

    selfie_mpi_global_data[42].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[42].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_delete_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_delete_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[42];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_delete_attr");
    }

    selfie_mpi_global_data[42].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[42].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_disconnect
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_disconnect(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[43];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_disconnect");
    }

    selfie_mpi_global_data[43].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[43].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_disconnect
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_disconnect(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[43];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_disconnect");
    }

    selfie_mpi_global_data[43].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[43].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_dup
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_dup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[44];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_dup");
    }

    selfie_mpi_global_data[44].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[44].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_dup
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_dup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[44];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_dup");
    }

    selfie_mpi_global_data[44].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[44].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_dup_with_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_dup_with_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[45];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_dup_with_info");
    }

    selfie_mpi_global_data[45].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[45].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_dup_with_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_dup_with_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[45];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_dup_with_info");
    }

    selfie_mpi_global_data[45].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[45].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_free_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_free_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[46];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_free_keyval");
    }

    selfie_mpi_global_data[46].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[46].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_free_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_free_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[46];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_free_keyval");
    }

    selfie_mpi_global_data[46].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[46].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[47];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_free");
    }

    selfie_mpi_global_data[47].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[47].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[47];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_free");
    }

    selfie_mpi_global_data[47].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[47].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_get_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_get_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[48];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_attr");
    }

    selfie_mpi_global_data[48].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[48].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_get_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_get_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[48];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_attr");
    }

    selfie_mpi_global_data[48].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[48].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_get_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_get_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[49];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_errhandler");
    }

    selfie_mpi_global_data[49].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[49].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_get_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_get_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[49];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_errhandler");
    }

    selfie_mpi_global_data[49].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[49].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_get_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_get_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[50];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_info");
    }

    selfie_mpi_global_data[50].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[50].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_get_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_get_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[50];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_info");
    }

    selfie_mpi_global_data[50].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[50].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_get_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_get_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[51];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_name");
    }

    selfie_mpi_global_data[51].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[51].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_get_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_get_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[51];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_name");
    }

    selfie_mpi_global_data[51].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[51].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_get_parent
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_get_parent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[52];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_parent");
    }

    selfie_mpi_global_data[52].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[52].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_get_parent
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_get_parent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[52];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_get_parent");
    }

    selfie_mpi_global_data[52].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[52].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_group
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[53];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_group");
    }

    selfie_mpi_global_data[53].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[53].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_group
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[53];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_group");
    }

    selfie_mpi_global_data[53].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[53].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_idup
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_idup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[54];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_idup");
    }

    selfie_mpi_global_data[54].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[54].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_idup
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_idup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[54];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_idup");
    }

    selfie_mpi_global_data[54].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[54].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_join
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_join(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[55];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_join");
    }

    selfie_mpi_global_data[55].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[55].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_join
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_join(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[55];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_join");
    }

    selfie_mpi_global_data[55].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[55].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_rank
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_rank(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[56];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_rank");
    }

    selfie_mpi_global_data[56].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[56].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_rank
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_rank(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[56];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_rank");
    }

    selfie_mpi_global_data[56].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[56].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_remote_group
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_remote_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[57];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_remote_group");
    }

    selfie_mpi_global_data[57].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[57].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_remote_group
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_remote_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[57];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_remote_group");
    }

    selfie_mpi_global_data[57].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[57].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_remote_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_remote_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[58];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_remote_size");
    }

    selfie_mpi_global_data[58].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[58].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_remote_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_remote_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[58];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_remote_size");
    }

    selfie_mpi_global_data[58].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[58].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_set_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_set_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[59];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_attr");
    }

    selfie_mpi_global_data[59].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[59].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_set_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_set_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[59];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_attr");
    }

    selfie_mpi_global_data[59].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[59].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_set_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_set_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[60];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_errhandler");
    }

    selfie_mpi_global_data[60].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[60].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_set_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_set_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[60];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_errhandler");
    }

    selfie_mpi_global_data[60].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[60].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_set_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_set_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[61];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_info");
    }

    selfie_mpi_global_data[61].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[61].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_set_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_set_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[61];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_info");
    }

    selfie_mpi_global_data[61].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[61].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_set_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_set_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[62];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_name");
    }

    selfie_mpi_global_data[62].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[62].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_set_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_set_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[62];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_set_name");
    }

    selfie_mpi_global_data[62].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[62].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[63];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_size");
    }

    selfie_mpi_global_data[63].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[63].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[63];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_size");
    }

    selfie_mpi_global_data[63].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[63].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_spawn
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_spawn(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[64];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_spawn");
    }

    selfie_mpi_global_data[64].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[64].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_spawn
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_spawn(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[64];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_spawn");
    }

    selfie_mpi_global_data[64].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[64].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_spawn_multiple
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_spawn_multiple(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[65];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_spawn_multiple");
    }

    selfie_mpi_global_data[65].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[65].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_spawn_multiple
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_spawn_multiple(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[65];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_spawn_multiple");
    }

    selfie_mpi_global_data[65].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[65].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_split
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_split(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[66];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_split");
    }

    selfie_mpi_global_data[66].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[66].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_split
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_split(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[66];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_split");
    }

    selfie_mpi_global_data[66].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[66].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_split_type
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_split_type(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[67];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_split_type");
    }

    selfie_mpi_global_data[67].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[67].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_split_type
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_split_type(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[67];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_split_type");
    }

    selfie_mpi_global_data[67].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[67].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Comm_test_inter
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Comm_test_inter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[68];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_test_inter");
    }

    selfie_mpi_global_data[68].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[68].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Comm_test_inter
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Comm_test_inter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[68];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Comm_test_inter");
    }

    selfie_mpi_global_data[68].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[68].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Compare_and_swap
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Compare_and_swap(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[69];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Compare_and_swap");
    }

    selfie_mpi_global_data[69].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[69].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Compare_and_swap
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Compare_and_swap(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[69];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Compare_and_swap");
    }

    selfie_mpi_global_data[69].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[69].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Dims_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Dims_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[70];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dims_create");
    }

    selfie_mpi_global_data[70].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[70].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Dims_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Dims_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[70];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dims_create");
    }

    selfie_mpi_global_data[70].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[70].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Dist_graph_create_adjacent
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Dist_graph_create_adjacent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[71];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_create_adjacent");
    }

    selfie_mpi_global_data[71].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[71].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Dist_graph_create_adjacent
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Dist_graph_create_adjacent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[71];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_create_adjacent");
    }

    selfie_mpi_global_data[71].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[71].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Dist_graph_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Dist_graph_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[72];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_create");
    }

    selfie_mpi_global_data[72].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[72].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Dist_graph_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Dist_graph_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[72];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_create");
    }

    selfie_mpi_global_data[72].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[72].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Dist_graph_neighbors_count
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Dist_graph_neighbors_count(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[73];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_neighbors_count");
    }

    selfie_mpi_global_data[73].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[73].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Dist_graph_neighbors_count
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Dist_graph_neighbors_count(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[73];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_neighbors_count");
    }

    selfie_mpi_global_data[73].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[73].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Dist_graph_neighbors
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Dist_graph_neighbors(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[74];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_neighbors");
    }

    selfie_mpi_global_data[74].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[74].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Dist_graph_neighbors
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Dist_graph_neighbors(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[74];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Dist_graph_neighbors");
    }

    selfie_mpi_global_data[74].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[74].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Errhandler_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Errhandler_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[75];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_create");
    }

    selfie_mpi_global_data[75].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[75].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Errhandler_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Errhandler_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[75];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_create");
    }

    selfie_mpi_global_data[75].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[75].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Errhandler_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Errhandler_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[76];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_free");
    }

    selfie_mpi_global_data[76].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[76].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Errhandler_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Errhandler_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[76];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_free");
    }

    selfie_mpi_global_data[76].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[76].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Errhandler_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Errhandler_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[77];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_get");
    }

    selfie_mpi_global_data[77].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[77].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Errhandler_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Errhandler_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[77];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_get");
    }

    selfie_mpi_global_data[77].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[77].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Errhandler_set
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Errhandler_set(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[78];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_set");
    }

    selfie_mpi_global_data[78].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[78].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Errhandler_set
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Errhandler_set(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[78];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Errhandler_set");
    }

    selfie_mpi_global_data[78].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[78].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Error_class
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Error_class(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[79];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Error_class");
    }

    selfie_mpi_global_data[79].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[79].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Error_class
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Error_class(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[79];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Error_class");
    }

    selfie_mpi_global_data[79].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[79].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Error_string
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Error_string(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[80];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Error_string");
    }

    selfie_mpi_global_data[80].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[80].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Error_string
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Error_string(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[80];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Error_string");
    }

    selfie_mpi_global_data[80].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[80].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Exscan
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Exscan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[81];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Exscan");
    }

    selfie_mpi_global_data[81].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[81].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Exscan
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Exscan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[81];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Exscan");
    }

    selfie_mpi_global_data[81].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[81].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Fetch_and_op
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Fetch_and_op(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[82];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Fetch_and_op");
    }

    selfie_mpi_global_data[82].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[82].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Fetch_and_op
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Fetch_and_op(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[82];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Fetch_and_op");
    }

    selfie_mpi_global_data[82].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[82].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Finalized
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Finalized(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[83];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Finalized");
    }

    selfie_mpi_global_data[83].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[83].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Finalized
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Finalized(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[83];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Finalized");
    }

    selfie_mpi_global_data[83].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[83].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Finalize
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Finalize(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[84];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Finalize");
    }

    selfie_mpi_global_data[84].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[84].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Finalize
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Finalize(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[84];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Finalize");
    }

    selfie_mpi_global_data[84].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[84].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Free_mem
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Free_mem(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[85];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Free_mem");
    }

    selfie_mpi_global_data[85].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[85].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Free_mem
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Free_mem(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[85];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Free_mem");
    }

    selfie_mpi_global_data[85].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[85].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Gather
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Gather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[86];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Gather");
    }

    selfie_mpi_global_data[86].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[86].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Gather
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Gather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[86];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Gather");
    }

    selfie_mpi_global_data[86].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[86].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Gatherv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Gatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[87];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Gatherv");
    }

    selfie_mpi_global_data[87].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[87].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Gatherv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Gatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[87];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Gatherv");
    }

    selfie_mpi_global_data[87].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[87].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_accumulate
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_accumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[88];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_accumulate");
    }

    selfie_mpi_global_data[88].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[88].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_accumulate
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_accumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[88];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_accumulate");
    }

    selfie_mpi_global_data[88].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[88].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_address
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_address(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[89];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_address");
    }

    selfie_mpi_global_data[89].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[89].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_address
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_address(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[89];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_address");
    }

    selfie_mpi_global_data[89].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[89].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_count
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_count(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[90];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_count");
    }

    selfie_mpi_global_data[90].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[90].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_count
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_count(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[90];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_count");
    }

    selfie_mpi_global_data[90].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[90].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_elements
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_elements(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[91];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_elements");
    }

    selfie_mpi_global_data[91].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[91].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_elements
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_elements(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[91];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_elements");
    }

    selfie_mpi_global_data[91].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[91].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_elements_x
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_elements_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[92];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_elements_x");
    }

    selfie_mpi_global_data[92].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[92].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_elements_x
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_elements_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[92];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_elements_x");
    }

    selfie_mpi_global_data[92].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[92].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_library_version
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_library_version(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[93];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_library_version");
    }

    selfie_mpi_global_data[93].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[93].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_library_version
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_library_version(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[93];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_library_version");
    }

    selfie_mpi_global_data[93].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[93].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_processor_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_processor_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[94];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_processor_name");
    }

    selfie_mpi_global_data[94].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[94].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_processor_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_processor_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[94];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_processor_name");
    }

    selfie_mpi_global_data[94].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[94].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get_version
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get_version(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[95];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_version");
    }

    selfie_mpi_global_data[95].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[95].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get_version
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get_version(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[95];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get_version");
    }

    selfie_mpi_global_data[95].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[95].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[96];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get");
    }

    selfie_mpi_global_data[96].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[96].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[96];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Get");
    }

    selfie_mpi_global_data[96].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[96].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Graph_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Graph_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[97];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_create");
    }

    selfie_mpi_global_data[97].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[97].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Graph_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Graph_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[97];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_create");
    }

    selfie_mpi_global_data[97].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[97].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Graphdims_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Graphdims_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[98];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graphdims_get");
    }

    selfie_mpi_global_data[98].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[98].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Graphdims_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Graphdims_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[98];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graphdims_get");
    }

    selfie_mpi_global_data[98].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[98].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Graph_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Graph_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[99];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_get");
    }

    selfie_mpi_global_data[99].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[99].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Graph_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Graph_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[99];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_get");
    }

    selfie_mpi_global_data[99].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[99].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Graph_map
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Graph_map(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[100];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_map");
    }

    selfie_mpi_global_data[100].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[100].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Graph_map
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Graph_map(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[100];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_map");
    }

    selfie_mpi_global_data[100].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[100].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Graph_neighbors_count
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Graph_neighbors_count(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[101];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_neighbors_count");
    }

    selfie_mpi_global_data[101].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[101].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Graph_neighbors_count
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Graph_neighbors_count(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[101];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_neighbors_count");
    }

    selfie_mpi_global_data[101].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[101].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Graph_neighbors
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Graph_neighbors(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[102];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_neighbors");
    }

    selfie_mpi_global_data[102].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[102].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Graph_neighbors
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Graph_neighbors(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[102];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Graph_neighbors");
    }

    selfie_mpi_global_data[102].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[102].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Grequest_complete
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Grequest_complete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[103];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Grequest_complete");
    }

    selfie_mpi_global_data[103].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[103].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Grequest_complete
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Grequest_complete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[103];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Grequest_complete");
    }

    selfie_mpi_global_data[103].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[103].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Grequest_start
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Grequest_start(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[104];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Grequest_start");
    }

    selfie_mpi_global_data[104].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[104].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Grequest_start
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Grequest_start(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[104];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Grequest_start");
    }

    selfie_mpi_global_data[104].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[104].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_compare
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_compare(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[105];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_compare");
    }

    selfie_mpi_global_data[105].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[105].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_compare
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_compare(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[105];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_compare");
    }

    selfie_mpi_global_data[105].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[105].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_difference
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_difference(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[106];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_difference");
    }

    selfie_mpi_global_data[106].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[106].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_difference
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_difference(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[106];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_difference");
    }

    selfie_mpi_global_data[106].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[106].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_excl
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_excl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[107];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_excl");
    }

    selfie_mpi_global_data[107].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[107].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_excl
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_excl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[107];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_excl");
    }

    selfie_mpi_global_data[107].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[107].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[108];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_free");
    }

    selfie_mpi_global_data[108].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[108].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[108];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_free");
    }

    selfie_mpi_global_data[108].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[108].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_incl
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_incl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[109];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_incl");
    }

    selfie_mpi_global_data[109].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[109].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_incl
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_incl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[109];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_incl");
    }

    selfie_mpi_global_data[109].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[109].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_intersection
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_intersection(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[110];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_intersection");
    }

    selfie_mpi_global_data[110].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[110].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_intersection
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_intersection(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[110];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_intersection");
    }

    selfie_mpi_global_data[110].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[110].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_range_excl
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_range_excl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[111];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_range_excl");
    }

    selfie_mpi_global_data[111].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[111].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_range_excl
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_range_excl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[111];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_range_excl");
    }

    selfie_mpi_global_data[111].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[111].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_range_incl
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_range_incl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[112];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_range_incl");
    }

    selfie_mpi_global_data[112].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[112].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_range_incl
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_range_incl(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[112];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_range_incl");
    }

    selfie_mpi_global_data[112].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[112].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_rank
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_rank(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[113];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_rank");
    }

    selfie_mpi_global_data[113].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[113].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_rank
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_rank(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[113];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_rank");
    }

    selfie_mpi_global_data[113].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[113].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[114];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_size");
    }

    selfie_mpi_global_data[114].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[114].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[114];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_size");
    }

    selfie_mpi_global_data[114].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[114].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_translate_ranks
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_translate_ranks(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[115];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_translate_ranks");
    }

    selfie_mpi_global_data[115].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[115].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_translate_ranks
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_translate_ranks(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[115];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_translate_ranks");
    }

    selfie_mpi_global_data[115].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[115].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Group_union
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Group_union(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[116];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_union");
    }

    selfie_mpi_global_data[116].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[116].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Group_union
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Group_union(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[116];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Group_union");
    }

    selfie_mpi_global_data[116].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[116].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iallgather
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iallgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[117];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iallgather");
    }

    selfie_mpi_global_data[117].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[117].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iallgather
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iallgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[117];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iallgather");
    }

    selfie_mpi_global_data[117].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[117].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iallgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iallgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[118];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iallgatherv");
    }

    selfie_mpi_global_data[118].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[118].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iallgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iallgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[118];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iallgatherv");
    }

    selfie_mpi_global_data[118].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[118].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iallreduce
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iallreduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[119];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iallreduce");
    }

    selfie_mpi_global_data[119].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[119].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iallreduce
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iallreduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[119];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iallreduce");
    }

    selfie_mpi_global_data[119].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[119].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ialltoall
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ialltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[120];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ialltoall");
    }

    selfie_mpi_global_data[120].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[120].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ialltoall
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ialltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[120];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ialltoall");
    }

    selfie_mpi_global_data[120].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[120].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ialltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ialltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[121];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ialltoallv");
    }

    selfie_mpi_global_data[121].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[121].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ialltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ialltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[121];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ialltoallv");
    }

    selfie_mpi_global_data[121].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[121].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ialltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ialltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[122];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ialltoallw");
    }

    selfie_mpi_global_data[122].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[122].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ialltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ialltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[122];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ialltoallw");
    }

    selfie_mpi_global_data[122].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[122].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ibarrier
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ibarrier(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[123];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ibarrier");
    }

    selfie_mpi_global_data[123].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[123].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ibarrier
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ibarrier(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[123];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ibarrier");
    }

    selfie_mpi_global_data[123].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[123].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ibcast
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ibcast(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[124];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ibcast");
    }

    selfie_mpi_global_data[124].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[124].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ibcast
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ibcast(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[124];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ibcast");
    }

    selfie_mpi_global_data[124].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[124].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ibsend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ibsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[125];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ibsend");
    }

    selfie_mpi_global_data[125].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[125].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ibsend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ibsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[125];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ibsend");
    }

    selfie_mpi_global_data[125].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[125].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iexscan
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iexscan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[126];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iexscan");
    }

    selfie_mpi_global_data[126].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[126].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iexscan
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iexscan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[126];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iexscan");
    }

    selfie_mpi_global_data[126].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[126].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Igather
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Igather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[127];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Igather");
    }

    selfie_mpi_global_data[127].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[127].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Igather
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Igather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[127];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Igather");
    }

    selfie_mpi_global_data[127].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[127].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Igatherv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Igatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[128];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Igatherv");
    }

    selfie_mpi_global_data[128].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[128].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Igatherv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Igatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[128];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Igatherv");
    }

    selfie_mpi_global_data[128].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[128].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Improbe
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Improbe(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[129];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Improbe");
    }

    selfie_mpi_global_data[129].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[129].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Improbe
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Improbe(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[129];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Improbe");
    }

    selfie_mpi_global_data[129].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[129].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Imrecv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Imrecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[130];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Imrecv");
    }

    selfie_mpi_global_data[130].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[130].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Imrecv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Imrecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[130];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Imrecv");
    }

    selfie_mpi_global_data[130].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[130].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ineighbor_allgather
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ineighbor_allgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[131];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_allgather");
    }

    selfie_mpi_global_data[131].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[131].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ineighbor_allgather
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ineighbor_allgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[131];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_allgather");
    }

    selfie_mpi_global_data[131].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[131].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ineighbor_allgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ineighbor_allgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[132];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_allgatherv");
    }

    selfie_mpi_global_data[132].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[132].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ineighbor_allgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ineighbor_allgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[132];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_allgatherv");
    }

    selfie_mpi_global_data[132].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[132].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ineighbor_alltoall
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ineighbor_alltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[133];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_alltoall");
    }

    selfie_mpi_global_data[133].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[133].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ineighbor_alltoall
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ineighbor_alltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[133];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_alltoall");
    }

    selfie_mpi_global_data[133].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[133].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ineighbor_alltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ineighbor_alltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[134];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_alltoallv");
    }

    selfie_mpi_global_data[134].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[134].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ineighbor_alltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ineighbor_alltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[134];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_alltoallv");
    }

    selfie_mpi_global_data[134].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[134].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ineighbor_alltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ineighbor_alltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[135];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_alltoallw");
    }

    selfie_mpi_global_data[135].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[135].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ineighbor_alltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ineighbor_alltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[135];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ineighbor_alltoallw");
    }

    selfie_mpi_global_data[135].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[135].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[136];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_create");
    }

    selfie_mpi_global_data[136].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[136].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[136];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_create");
    }

    selfie_mpi_global_data[136].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[136].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_delete
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_delete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[137];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_delete");
    }

    selfie_mpi_global_data[137].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[137].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_delete
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_delete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[137];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_delete");
    }

    selfie_mpi_global_data[137].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[137].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_dup
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_dup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[138];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_dup");
    }

    selfie_mpi_global_data[138].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[138].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_dup
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_dup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[138];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_dup");
    }

    selfie_mpi_global_data[138].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[138].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[139];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_free");
    }

    selfie_mpi_global_data[139].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[139].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[139];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_free");
    }

    selfie_mpi_global_data[139].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[139].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_get
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[140];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get");
    }

    selfie_mpi_global_data[140].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[140].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_get
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_get(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[140];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get");
    }

    selfie_mpi_global_data[140].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[140].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_get_nkeys
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_get_nkeys(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[141];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get_nkeys");
    }

    selfie_mpi_global_data[141].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[141].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_get_nkeys
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_get_nkeys(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[141];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get_nkeys");
    }

    selfie_mpi_global_data[141].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[141].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_get_nthkey
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_get_nthkey(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[142];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get_nthkey");
    }

    selfie_mpi_global_data[142].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[142].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_get_nthkey
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_get_nthkey(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[142];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get_nthkey");
    }

    selfie_mpi_global_data[142].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[142].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_get_valuelen
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_get_valuelen(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[143];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get_valuelen");
    }

    selfie_mpi_global_data[143].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[143].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_get_valuelen
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_get_valuelen(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[143];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_get_valuelen");
    }

    selfie_mpi_global_data[143].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[143].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Info_set
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Info_set(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[144];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_set");
    }

    selfie_mpi_global_data[144].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[144].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Info_set
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Info_set(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[144];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Info_set");
    }

    selfie_mpi_global_data[144].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[144].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Initialized
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Initialized(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[145];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Initialized");
    }

    selfie_mpi_global_data[145].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[145].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Initialized
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Initialized(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[145];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Initialized");
    }

    selfie_mpi_global_data[145].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[145].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Init
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[146];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Init");
    }

    selfie_mpi_global_data[146].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[146].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Init
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[146];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Init");
    }

    selfie_mpi_global_data[146].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[146].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Init_thread
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Init_thread(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[147];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Init_thread");
    }

    selfie_mpi_global_data[147].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[147].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Init_thread
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Init_thread(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[147];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Init_thread");
    }

    selfie_mpi_global_data[147].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[147].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Intercomm_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Intercomm_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[148];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Intercomm_create");
    }

    selfie_mpi_global_data[148].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[148].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Intercomm_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Intercomm_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[148];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Intercomm_create");
    }

    selfie_mpi_global_data[148].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[148].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Intercomm_merge
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Intercomm_merge(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[149];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Intercomm_merge");
    }

    selfie_mpi_global_data[149].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[149].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Intercomm_merge
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Intercomm_merge(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[149];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Intercomm_merge");
    }

    selfie_mpi_global_data[149].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[149].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Irecv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Irecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[150];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Irecv");
    }

    selfie_mpi_global_data[150].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[150].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Irecv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Irecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[150];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Irecv");
    }

    selfie_mpi_global_data[150].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[150].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ireduce
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ireduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[151];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ireduce");
    }

    selfie_mpi_global_data[151].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[151].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ireduce
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ireduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[151];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ireduce");
    }

    selfie_mpi_global_data[151].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[151].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ireduce_scatter_block
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ireduce_scatter_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[152];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ireduce_scatter_block");
    }

    selfie_mpi_global_data[152].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[152].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ireduce_scatter_block
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ireduce_scatter_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[152];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ireduce_scatter_block");
    }

    selfie_mpi_global_data[152].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[152].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ireduce_scatter
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ireduce_scatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[153];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ireduce_scatter");
    }

    selfie_mpi_global_data[153].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[153].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ireduce_scatter
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ireduce_scatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[153];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ireduce_scatter");
    }

    selfie_mpi_global_data[153].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[153].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Irsend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Irsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[154];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Irsend");
    }

    selfie_mpi_global_data[154].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[154].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Irsend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Irsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[154];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Irsend");
    }

    selfie_mpi_global_data[154].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[154].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iscan
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iscan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[155];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iscan");
    }

    selfie_mpi_global_data[155].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[155].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iscan
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iscan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[155];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iscan");
    }

    selfie_mpi_global_data[155].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[155].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iscatter
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iscatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[156];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iscatter");
    }

    selfie_mpi_global_data[156].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[156].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iscatter
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iscatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[156];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iscatter");
    }

    selfie_mpi_global_data[156].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[156].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Iscatterv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Iscatterv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[157];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iscatterv");
    }

    selfie_mpi_global_data[157].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[157].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Iscatterv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Iscatterv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[157];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Iscatterv");
    }

    selfie_mpi_global_data[157].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[157].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Isend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Isend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[158];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Isend");
    }

    selfie_mpi_global_data[158].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[158].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Isend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Isend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[158];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Isend");
    }

    selfie_mpi_global_data[158].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[158].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Issend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Issend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[159];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Issend");
    }

    selfie_mpi_global_data[159].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[159].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Issend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Issend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[159];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Issend");
    }

    selfie_mpi_global_data[159].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[159].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Is_thread_main
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Is_thread_main(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[160];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Is_thread_main");
    }

    selfie_mpi_global_data[160].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[160].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Is_thread_main
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Is_thread_main(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[160];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Is_thread_main");
    }

    selfie_mpi_global_data[160].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[160].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Keyval_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Keyval_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[161];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Keyval_create");
    }

    selfie_mpi_global_data[161].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[161].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Keyval_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Keyval_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[161];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Keyval_create");
    }

    selfie_mpi_global_data[161].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[161].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Keyval_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Keyval_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[162];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Keyval_free");
    }

    selfie_mpi_global_data[162].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[162].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Keyval_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Keyval_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[162];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Keyval_free");
    }

    selfie_mpi_global_data[162].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[162].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Lookup_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Lookup_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[163];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Lookup_name");
    }

    selfie_mpi_global_data[163].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[163].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Lookup_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Lookup_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[163];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Lookup_name");
    }

    selfie_mpi_global_data[163].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[163].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Mprobe
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Mprobe(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[164];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Mprobe");
    }

    selfie_mpi_global_data[164].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[164].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Mprobe
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Mprobe(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[164];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Mprobe");
    }

    selfie_mpi_global_data[164].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[164].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Mrecv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Mrecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[165];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Mrecv");
    }

    selfie_mpi_global_data[165].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[165].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Mrecv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Mrecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[165];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Mrecv");
    }

    selfie_mpi_global_data[165].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[165].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Neighbor_allgather
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Neighbor_allgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[166];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_allgather");
    }

    selfie_mpi_global_data[166].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[166].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Neighbor_allgather
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Neighbor_allgather(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[166];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_allgather");
    }

    selfie_mpi_global_data[166].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[166].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Neighbor_allgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Neighbor_allgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[167];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_allgatherv");
    }

    selfie_mpi_global_data[167].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[167].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Neighbor_allgatherv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Neighbor_allgatherv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[167];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_allgatherv");
    }

    selfie_mpi_global_data[167].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[167].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Neighbor_alltoall
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Neighbor_alltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[168];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_alltoall");
    }

    selfie_mpi_global_data[168].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[168].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Neighbor_alltoall
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Neighbor_alltoall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[168];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_alltoall");
    }

    selfie_mpi_global_data[168].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[168].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Neighbor_alltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Neighbor_alltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[169];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_alltoallv");
    }

    selfie_mpi_global_data[169].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[169].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Neighbor_alltoallv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Neighbor_alltoallv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[169];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_alltoallv");
    }

    selfie_mpi_global_data[169].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[169].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Neighbor_alltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Neighbor_alltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[170];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_alltoallw");
    }

    selfie_mpi_global_data[170].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[170].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Neighbor_alltoallw
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Neighbor_alltoallw(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[170];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Neighbor_alltoallw");
    }

    selfie_mpi_global_data[170].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[170].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Op_commutative
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Op_commutative(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[171];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Op_commutative");
    }

    selfie_mpi_global_data[171].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[171].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Op_commutative
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Op_commutative(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[171];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Op_commutative");
    }

    selfie_mpi_global_data[171].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[171].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Op_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Op_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[172];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Op_create");
    }

    selfie_mpi_global_data[172].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[172].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Op_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Op_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[172];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Op_create");
    }

    selfie_mpi_global_data[172].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[172].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Open_port
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Open_port(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[173];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Open_port");
    }

    selfie_mpi_global_data[173].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[173].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Open_port
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Open_port(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[173];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Open_port");
    }

    selfie_mpi_global_data[173].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[173].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Op_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Op_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[174];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Op_free");
    }

    selfie_mpi_global_data[174].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[174].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Op_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Op_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[174];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Op_free");
    }

    selfie_mpi_global_data[174].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[174].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Pack
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Pack(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[175];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack");
    }

    selfie_mpi_global_data[175].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[175].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Pack
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Pack(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[175];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack");
    }

    selfie_mpi_global_data[175].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[175].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Pack_external
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Pack_external(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[176];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack_external");
    }

    selfie_mpi_global_data[176].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[176].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Pack_external
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Pack_external(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[176];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack_external");
    }

    selfie_mpi_global_data[176].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[176].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Pack_external_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Pack_external_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[177];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack_external_size");
    }

    selfie_mpi_global_data[177].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[177].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Pack_external_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Pack_external_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[177];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack_external_size");
    }

    selfie_mpi_global_data[177].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[177].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Pack_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Pack_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[178];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack_size");
    }

    selfie_mpi_global_data[178].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[178].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Pack_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Pack_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[178];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Pack_size");
    }

    selfie_mpi_global_data[178].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[178].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Probe
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Probe(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[179];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Probe");
    }

    selfie_mpi_global_data[179].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[179].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Probe
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Probe(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[179];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Probe");
    }

    selfie_mpi_global_data[179].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[179].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Publish_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Publish_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[180];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Publish_name");
    }

    selfie_mpi_global_data[180].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[180].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Publish_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Publish_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[180];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Publish_name");
    }

    selfie_mpi_global_data[180].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[180].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Put
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Put(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[181];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Put");
    }

    selfie_mpi_global_data[181].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[181].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Put
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Put(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[181];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Put");
    }

    selfie_mpi_global_data[181].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[181].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Query_thread
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Query_thread(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[182];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Query_thread");
    }

    selfie_mpi_global_data[182].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[182].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Query_thread
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Query_thread(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[182];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Query_thread");
    }

    selfie_mpi_global_data[182].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[182].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Raccumulate
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Raccumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[183];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Raccumulate");
    }

    selfie_mpi_global_data[183].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[183].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Raccumulate
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Raccumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[183];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Raccumulate");
    }

    selfie_mpi_global_data[183].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[183].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Recv_init
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Recv_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[184];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Recv_init");
    }

    selfie_mpi_global_data[184].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[184].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Recv_init
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Recv_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[184];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Recv_init");
    }

    selfie_mpi_global_data[184].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[184].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Recv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Recv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[185];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Recv");
    }

    selfie_mpi_global_data[185].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[185].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Recv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Recv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[185];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Recv");
    }

    selfie_mpi_global_data[185].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[185].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Reduce
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Reduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[186];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce");
    }

    selfie_mpi_global_data[186].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[186].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Reduce
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Reduce(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[186];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce");
    }

    selfie_mpi_global_data[186].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[186].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Reduce_local
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Reduce_local(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[187];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce_local");
    }

    selfie_mpi_global_data[187].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[187].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Reduce_local
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Reduce_local(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[187];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce_local");
    }

    selfie_mpi_global_data[187].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[187].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Reduce_scatter_block
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Reduce_scatter_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[188];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce_scatter_block");
    }

    selfie_mpi_global_data[188].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[188].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Reduce_scatter_block
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Reduce_scatter_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[188];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce_scatter_block");
    }

    selfie_mpi_global_data[188].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[188].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Reduce_scatter
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Reduce_scatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[189];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce_scatter");
    }

    selfie_mpi_global_data[189].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[189].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Reduce_scatter
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Reduce_scatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[189];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Reduce_scatter");
    }

    selfie_mpi_global_data[189].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[189].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Register_datarep
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Register_datarep(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[190];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Register_datarep");
    }

    selfie_mpi_global_data[190].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[190].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Register_datarep
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Register_datarep(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[190];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Register_datarep");
    }

    selfie_mpi_global_data[190].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[190].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Request_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Request_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[191];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Request_free");
    }

    selfie_mpi_global_data[191].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[191].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Request_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Request_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[191];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Request_free");
    }

    selfie_mpi_global_data[191].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[191].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Request_get_status
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Request_get_status(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[192];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Request_get_status");
    }

    selfie_mpi_global_data[192].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[192].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Request_get_status
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Request_get_status(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[192];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Request_get_status");
    }

    selfie_mpi_global_data[192].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[192].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Rget_accumulate
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Rget_accumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[193];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rget_accumulate");
    }

    selfie_mpi_global_data[193].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[193].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Rget_accumulate
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Rget_accumulate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[193];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rget_accumulate");
    }

    selfie_mpi_global_data[193].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[193].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Rget
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Rget(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[194];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rget");
    }

    selfie_mpi_global_data[194].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[194].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Rget
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Rget(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[194];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rget");
    }

    selfie_mpi_global_data[194].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[194].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Rput
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Rput(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[195];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rput");
    }

    selfie_mpi_global_data[195].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[195].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Rput
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Rput(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[195];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rput");
    }

    selfie_mpi_global_data[195].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[195].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Rsend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Rsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[196];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rsend");
    }

    selfie_mpi_global_data[196].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[196].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Rsend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Rsend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[196];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rsend");
    }

    selfie_mpi_global_data[196].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[196].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Rsend_init
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Rsend_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[197];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rsend_init");
    }

    selfie_mpi_global_data[197].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[197].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Rsend_init
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Rsend_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[197];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Rsend_init");
    }

    selfie_mpi_global_data[197].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[197].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Scan
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Scan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[198];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Scan");
    }

    selfie_mpi_global_data[198].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[198].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Scan
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Scan(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[198];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Scan");
    }

    selfie_mpi_global_data[198].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[198].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Scatter
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Scatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[199];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Scatter");
    }

    selfie_mpi_global_data[199].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[199].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Scatter
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Scatter(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[199];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Scatter");
    }

    selfie_mpi_global_data[199].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[199].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Scatterv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Scatterv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[200];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Scatterv");
    }

    selfie_mpi_global_data[200].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[200].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Scatterv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Scatterv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[200];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Scatterv");
    }

    selfie_mpi_global_data[200].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[200].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Send
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Send(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[201];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Send");
    }

    selfie_mpi_global_data[201].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[201].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Send
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Send(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[201];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Send");
    }

    selfie_mpi_global_data[201].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[201].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Send_init
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Send_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[202];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Send_init");
    }

    selfie_mpi_global_data[202].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[202].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Send_init
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Send_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[202];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Send_init");
    }

    selfie_mpi_global_data[202].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[202].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Sendrecv
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Sendrecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[203];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Sendrecv");
    }

    selfie_mpi_global_data[203].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[203].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Sendrecv
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Sendrecv(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[203];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Sendrecv");
    }

    selfie_mpi_global_data[203].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[203].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Sendrecv_replace
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Sendrecv_replace(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[204];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Sendrecv_replace");
    }

    selfie_mpi_global_data[204].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[204].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Sendrecv_replace
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Sendrecv_replace(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[204];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Sendrecv_replace");
    }

    selfie_mpi_global_data[204].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[204].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ssend
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ssend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[205];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ssend");
    }

    selfie_mpi_global_data[205].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[205].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ssend
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ssend(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[205];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ssend");
    }

    selfie_mpi_global_data[205].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[205].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Ssend_init
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Ssend_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[206];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ssend_init");
    }

    selfie_mpi_global_data[206].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[206].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Ssend_init
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Ssend_init(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[206];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Ssend_init");
    }

    selfie_mpi_global_data[206].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[206].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Startall
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Startall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[207];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Startall");
    }

    selfie_mpi_global_data[207].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[207].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Startall
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Startall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[207];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Startall");
    }

    selfie_mpi_global_data[207].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[207].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Start
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Start(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[208];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Start");
    }

    selfie_mpi_global_data[208].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[208].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Start
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Start(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[208];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Start");
    }

    selfie_mpi_global_data[208].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[208].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Status_set_cancelled
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Status_set_cancelled(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[209];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Status_set_cancelled");
    }

    selfie_mpi_global_data[209].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[209].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Status_set_cancelled
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Status_set_cancelled(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[209];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Status_set_cancelled");
    }

    selfie_mpi_global_data[209].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[209].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Status_set_elements
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Status_set_elements(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[210];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Status_set_elements");
    }

    selfie_mpi_global_data[210].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[210].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Status_set_elements
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Status_set_elements(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[210];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Status_set_elements");
    }

    selfie_mpi_global_data[210].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[210].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Status_set_elements_x
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Status_set_elements_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[211];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Status_set_elements_x");
    }

    selfie_mpi_global_data[211].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[211].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Status_set_elements_x
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Status_set_elements_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[211];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Status_set_elements_x");
    }

    selfie_mpi_global_data[211].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[211].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Topo_test
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Topo_test(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[212];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Topo_test");
    }

    selfie_mpi_global_data[212].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[212].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Topo_test
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Topo_test(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[212];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Topo_test");
    }

    selfie_mpi_global_data[212].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[212].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_commit
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_commit(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[213];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_commit");
    }

    selfie_mpi_global_data[213].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[213].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_commit
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_commit(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[213];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_commit");
    }

    selfie_mpi_global_data[213].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[213].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_contiguous
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_contiguous(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[214];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_contiguous");
    }

    selfie_mpi_global_data[214].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[214].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_contiguous
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_contiguous(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[214];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_contiguous");
    }

    selfie_mpi_global_data[214].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[214].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_darray
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_darray(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[215];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_darray");
    }

    selfie_mpi_global_data[215].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[215].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_darray
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_darray(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[215];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_darray");
    }

    selfie_mpi_global_data[215].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[215].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_f90_complex
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_f90_complex(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[216];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_f90_complex");
    }

    selfie_mpi_global_data[216].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[216].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_f90_complex
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_f90_complex(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[216];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_f90_complex");
    }

    selfie_mpi_global_data[216].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[216].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_f90_integer
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_f90_integer(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[217];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_f90_integer");
    }

    selfie_mpi_global_data[217].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[217].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_f90_integer
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_f90_integer(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[217];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_f90_integer");
    }

    selfie_mpi_global_data[217].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[217].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_f90_real
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_f90_real(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[218];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_f90_real");
    }

    selfie_mpi_global_data[218].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[218].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_f90_real
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_f90_real(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[218];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_f90_real");
    }

    selfie_mpi_global_data[218].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[218].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_hindexed_block
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_hindexed_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[219];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_hindexed_block");
    }

    selfie_mpi_global_data[219].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[219].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_hindexed_block
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_hindexed_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[219];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_hindexed_block");
    }

    selfie_mpi_global_data[219].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[219].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_hindexed
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_hindexed(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[220];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_hindexed");
    }

    selfie_mpi_global_data[220].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[220].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_hindexed
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_hindexed(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[220];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_hindexed");
    }

    selfie_mpi_global_data[220].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[220].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_hvector
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_hvector(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[221];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_hvector");
    }

    selfie_mpi_global_data[221].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[221].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_hvector
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_hvector(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[221];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_hvector");
    }

    selfie_mpi_global_data[221].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[221].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_indexed_block
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_indexed_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[222];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_indexed_block");
    }

    selfie_mpi_global_data[222].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[222].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_indexed_block
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_indexed_block(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[222];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_indexed_block");
    }

    selfie_mpi_global_data[222].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[222].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[223];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_keyval");
    }

    selfie_mpi_global_data[223].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[223].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[223];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_keyval");
    }

    selfie_mpi_global_data[223].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[223].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_resized
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_resized(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[224];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_resized");
    }

    selfie_mpi_global_data[224].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[224].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_resized
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_resized(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[224];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_resized");
    }

    selfie_mpi_global_data[224].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[224].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_struct
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_struct(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[225];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_struct");
    }

    selfie_mpi_global_data[225].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[225].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_struct
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_struct(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[225];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_struct");
    }

    selfie_mpi_global_data[225].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[225].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_create_subarray
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_create_subarray(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[226];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_subarray");
    }

    selfie_mpi_global_data[226].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[226].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_create_subarray
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_create_subarray(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[226];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_create_subarray");
    }

    selfie_mpi_global_data[226].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[226].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_delete_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_delete_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[227];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_delete_attr");
    }

    selfie_mpi_global_data[227].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[227].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_delete_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_delete_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[227];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_delete_attr");
    }

    selfie_mpi_global_data[227].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[227].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_dup
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_dup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[228];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_dup");
    }

    selfie_mpi_global_data[228].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[228].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_dup
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_dup(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[228];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_dup");
    }

    selfie_mpi_global_data[228].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[228].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_extent
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[229];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_extent");
    }

    selfie_mpi_global_data[229].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[229].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_extent
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[229];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_extent");
    }

    selfie_mpi_global_data[229].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[229].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_free_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_free_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[230];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_free_keyval");
    }

    selfie_mpi_global_data[230].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[230].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_free_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_free_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[230];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_free_keyval");
    }

    selfie_mpi_global_data[230].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[230].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[231];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_free");
    }

    selfie_mpi_global_data[231].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[231].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[231];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_free");
    }

    selfie_mpi_global_data[231].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[231].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[232];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_attr");
    }

    selfie_mpi_global_data[232].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[232].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[232];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_attr");
    }

    selfie_mpi_global_data[232].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[232].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_contents
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_contents(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[233];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_contents");
    }

    selfie_mpi_global_data[233].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[233].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_contents
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_contents(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[233];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_contents");
    }

    selfie_mpi_global_data[233].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[233].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_envelope
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_envelope(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[234];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_envelope");
    }

    selfie_mpi_global_data[234].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[234].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_envelope
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_envelope(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[234];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_envelope");
    }

    selfie_mpi_global_data[234].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[234].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_extent
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[235];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_extent");
    }

    selfie_mpi_global_data[235].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[235].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_extent
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[235];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_extent");
    }

    selfie_mpi_global_data[235].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[235].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_extent_x
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_extent_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[236];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_extent_x");
    }

    selfie_mpi_global_data[236].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[236].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_extent_x
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_extent_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[236];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_extent_x");
    }

    selfie_mpi_global_data[236].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[236].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[237];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_name");
    }

    selfie_mpi_global_data[237].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[237].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[237];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_name");
    }

    selfie_mpi_global_data[237].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[237].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_true_extent
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_true_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[238];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_true_extent");
    }

    selfie_mpi_global_data[238].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[238].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_true_extent
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_true_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[238];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_true_extent");
    }

    selfie_mpi_global_data[238].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[238].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_get_true_extent_x
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_get_true_extent_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[239];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_true_extent_x");
    }

    selfie_mpi_global_data[239].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[239].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_get_true_extent_x
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_get_true_extent_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[239];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_get_true_extent_x");
    }

    selfie_mpi_global_data[239].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[239].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_hindexed
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_hindexed(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[240];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_hindexed");
    }

    selfie_mpi_global_data[240].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[240].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_hindexed
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_hindexed(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[240];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_hindexed");
    }

    selfie_mpi_global_data[240].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[240].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_hvector
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_hvector(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[241];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_hvector");
    }

    selfie_mpi_global_data[241].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[241].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_hvector
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_hvector(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[241];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_hvector");
    }

    selfie_mpi_global_data[241].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[241].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_indexed
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_indexed(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[242];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_indexed");
    }

    selfie_mpi_global_data[242].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[242].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_indexed
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_indexed(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[242];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_indexed");
    }

    selfie_mpi_global_data[242].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[242].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_lb
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_lb(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[243];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_lb");
    }

    selfie_mpi_global_data[243].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[243].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_lb
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_lb(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[243];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_lb");
    }

    selfie_mpi_global_data[243].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[243].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_match_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_match_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[244];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_match_size");
    }

    selfie_mpi_global_data[244].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[244].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_match_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_match_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[244];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_match_size");
    }

    selfie_mpi_global_data[244].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[244].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_set_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_set_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[245];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_set_attr");
    }

    selfie_mpi_global_data[245].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[245].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_set_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_set_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[245];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_set_attr");
    }

    selfie_mpi_global_data[245].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[245].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_set_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_set_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[246];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_set_name");
    }

    selfie_mpi_global_data[246].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[246].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_set_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_set_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[246];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_set_name");
    }

    selfie_mpi_global_data[246].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[246].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[247];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_size");
    }

    selfie_mpi_global_data[247].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[247].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[247];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_size");
    }

    selfie_mpi_global_data[247].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[247].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_size_x
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_size_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[248];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_size_x");
    }

    selfie_mpi_global_data[248].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[248].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_size_x
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_size_x(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[248];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_size_x");
    }

    selfie_mpi_global_data[248].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[248].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_struct
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_struct(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[249];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_struct");
    }

    selfie_mpi_global_data[249].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[249].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_struct
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_struct(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[249];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_struct");
    }

    selfie_mpi_global_data[249].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[249].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_ub
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_ub(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[250];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_ub");
    }

    selfie_mpi_global_data[250].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[250].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_ub
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_ub(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[250];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_ub");
    }

    selfie_mpi_global_data[250].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[250].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Type_vector
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Type_vector(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[251];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_vector");
    }

    selfie_mpi_global_data[251].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[251].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Type_vector
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Type_vector(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[251];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Type_vector");
    }

    selfie_mpi_global_data[251].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[251].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Unpack
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Unpack(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[252];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Unpack");
    }

    selfie_mpi_global_data[252].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[252].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Unpack
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Unpack(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[252];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Unpack");
    }

    selfie_mpi_global_data[252].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[252].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Unpack_external
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Unpack_external(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[253];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Unpack_external");
    }

    selfie_mpi_global_data[253].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[253].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Unpack_external
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Unpack_external(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[253];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Unpack_external");
    }

    selfie_mpi_global_data[253].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[253].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Unpublish_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Unpublish_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[254];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Unpublish_name");
    }

    selfie_mpi_global_data[254].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[254].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Unpublish_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Unpublish_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[254];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Unpublish_name");
    }

    selfie_mpi_global_data[254].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[254].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Waitall
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Waitall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[255];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Waitall");
    }

    selfie_mpi_global_data[255].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[255].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Waitall
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Waitall(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[255];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Waitall");
    }

    selfie_mpi_global_data[255].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[255].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Waitany
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Waitany(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[256];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Waitany");
    }

    selfie_mpi_global_data[256].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[256].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Waitany
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Waitany(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[256];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Waitany");
    }

    selfie_mpi_global_data[256].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[256].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Wait
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Wait(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[257];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Wait");
    }

    selfie_mpi_global_data[257].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[257].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Wait
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Wait(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[257];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Wait");
    }

    selfie_mpi_global_data[257].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[257].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Waitsome
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Waitsome(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[258];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Waitsome");
    }

    selfie_mpi_global_data[258].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[258].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Waitsome
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Waitsome(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[258];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Waitsome");
    }

    selfie_mpi_global_data[258].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[258].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_allocate
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_allocate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[259];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_allocate");
    }

    selfie_mpi_global_data[259].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[259].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_allocate
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_allocate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[259];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_allocate");
    }

    selfie_mpi_global_data[259].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[259].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_allocate_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_allocate_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[260];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_allocate_shared");
    }

    selfie_mpi_global_data[260].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[260].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_allocate_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_allocate_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[260];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_allocate_shared");
    }

    selfie_mpi_global_data[260].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[260].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_attach
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_attach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[261];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_attach");
    }

    selfie_mpi_global_data[261].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[261].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_attach
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_attach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[261];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_attach");
    }

    selfie_mpi_global_data[261].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[261].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_call_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_call_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[262];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_call_errhandler");
    }

    selfie_mpi_global_data[262].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[262].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_call_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_call_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[262];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_call_errhandler");
    }

    selfie_mpi_global_data[262].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[262].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_complete
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_complete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[263];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_complete");
    }

    selfie_mpi_global_data[263].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[263].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_complete
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_complete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[263];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_complete");
    }

    selfie_mpi_global_data[263].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[263].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_create_dynamic
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_create_dynamic(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[264];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create_dynamic");
    }

    selfie_mpi_global_data[264].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[264].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_create_dynamic
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_create_dynamic(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[264];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create_dynamic");
    }

    selfie_mpi_global_data[264].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[264].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_create_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_create_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[265];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create_errhandler");
    }

    selfie_mpi_global_data[265].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[265].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_create_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_create_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[265];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create_errhandler");
    }

    selfie_mpi_global_data[265].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[265].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_create_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_create_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[266];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create_keyval");
    }

    selfie_mpi_global_data[266].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[266].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_create_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_create_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[266];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create_keyval");
    }

    selfie_mpi_global_data[266].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[266].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_create
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[267];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create");
    }

    selfie_mpi_global_data[267].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[267].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_create
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_create(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[267];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_create");
    }

    selfie_mpi_global_data[267].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[267].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_delete_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_delete_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[268];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_delete_attr");
    }

    selfie_mpi_global_data[268].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[268].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_delete_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_delete_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[268];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_delete_attr");
    }

    selfie_mpi_global_data[268].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[268].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_detach
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_detach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[269];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_detach");
    }

    selfie_mpi_global_data[269].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[269].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_detach
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_detach(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[269];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_detach");
    }

    selfie_mpi_global_data[269].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[269].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_fence
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_fence(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[270];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_fence");
    }

    selfie_mpi_global_data[270].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[270].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_fence
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_fence(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[270];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_fence");
    }

    selfie_mpi_global_data[270].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[270].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_flush_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_flush_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[271];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush_all");
    }

    selfie_mpi_global_data[271].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[271].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_flush_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_flush_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[271];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush_all");
    }

    selfie_mpi_global_data[271].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[271].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_flush
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_flush(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[272];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush");
    }

    selfie_mpi_global_data[272].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[272].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_flush
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_flush(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[272];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush");
    }

    selfie_mpi_global_data[272].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[272].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_flush_local_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_flush_local_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[273];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush_local_all");
    }

    selfie_mpi_global_data[273].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[273].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_flush_local_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_flush_local_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[273];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush_local_all");
    }

    selfie_mpi_global_data[273].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[273].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_flush_local
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_flush_local(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[274];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush_local");
    }

    selfie_mpi_global_data[274].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[274].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_flush_local
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_flush_local(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[274];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_flush_local");
    }

    selfie_mpi_global_data[274].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[274].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_free_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_free_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[275];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_free_keyval");
    }

    selfie_mpi_global_data[275].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[275].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_free_keyval
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_free_keyval(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[275];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_free_keyval");
    }

    selfie_mpi_global_data[275].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[275].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_free
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[276];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_free");
    }

    selfie_mpi_global_data[276].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[276].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_free
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_free(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[276];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_free");
    }

    selfie_mpi_global_data[276].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[276].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_get_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_get_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[277];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_attr");
    }

    selfie_mpi_global_data[277].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[277].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_get_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_get_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[277];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_attr");
    }

    selfie_mpi_global_data[277].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[277].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_get_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_get_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[278];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_errhandler");
    }

    selfie_mpi_global_data[278].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[278].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_get_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_get_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[278];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_errhandler");
    }

    selfie_mpi_global_data[278].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[278].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_get_group
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_get_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[279];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_group");
    }

    selfie_mpi_global_data[279].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[279].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_get_group
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_get_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[279];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_group");
    }

    selfie_mpi_global_data[279].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[279].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_get_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_get_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[280];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_info");
    }

    selfie_mpi_global_data[280].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[280].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_get_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_get_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[280];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_info");
    }

    selfie_mpi_global_data[280].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[280].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_get_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_get_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[281];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_name");
    }

    selfie_mpi_global_data[281].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[281].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_get_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_get_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[281];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_get_name");
    }

    selfie_mpi_global_data[281].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[281].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_lock_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_lock_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[282];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_lock_all");
    }

    selfie_mpi_global_data[282].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[282].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_lock_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_lock_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[282];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_lock_all");
    }

    selfie_mpi_global_data[282].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[282].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_lock
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_lock(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[283];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_lock");
    }

    selfie_mpi_global_data[283].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[283].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_lock
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_lock(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[283];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_lock");
    }

    selfie_mpi_global_data[283].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[283].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_post
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_post(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[284];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_post");
    }

    selfie_mpi_global_data[284].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[284].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_post
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_post(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[284];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_post");
    }

    selfie_mpi_global_data[284].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[284].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_set_attr
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_set_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[285];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_attr");
    }

    selfie_mpi_global_data[285].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[285].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_set_attr
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_set_attr(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[285];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_attr");
    }

    selfie_mpi_global_data[285].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[285].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_set_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_set_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[286];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_errhandler");
    }

    selfie_mpi_global_data[286].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[286].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_set_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_set_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[286];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_errhandler");
    }

    selfie_mpi_global_data[286].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[286].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_set_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_set_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[287];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_info");
    }

    selfie_mpi_global_data[287].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[287].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_set_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_set_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[287];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_info");
    }

    selfie_mpi_global_data[287].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[287].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_set_name
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_set_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[288];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_name");
    }

    selfie_mpi_global_data[288].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[288].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_set_name
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_set_name(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[288];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_set_name");
    }

    selfie_mpi_global_data[288].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[288].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_shared_query
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_shared_query(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[289];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_shared_query");
    }

    selfie_mpi_global_data[289].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[289].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_shared_query
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_shared_query(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[289];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_shared_query");
    }

    selfie_mpi_global_data[289].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[289].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_start
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_start(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[290];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_start");
    }

    selfie_mpi_global_data[290].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[290].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_start
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_start(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[290];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_start");
    }

    selfie_mpi_global_data[290].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[290].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_sync
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_sync(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[291];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_sync");
    }

    selfie_mpi_global_data[291].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[291].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_sync
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_sync(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[291];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_sync");
    }

    selfie_mpi_global_data[291].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[291].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_unlock_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_unlock_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[292];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_unlock_all");
    }

    selfie_mpi_global_data[292].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[292].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_unlock_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_unlock_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[292];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_unlock_all");
    }

    selfie_mpi_global_data[292].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[292].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_unlock
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_unlock(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[293];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_unlock");
    }

    selfie_mpi_global_data[293].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[293].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_unlock
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_unlock(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[293];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_unlock");
    }

    selfie_mpi_global_data[293].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[293].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_Win_wait
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_Win_wait(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[294];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_wait");
    }

    selfie_mpi_global_data[294].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[294].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_Win_wait
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_Win_wait(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpi_pointer_functions[294];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_Win_wait");
    }

    selfie_mpi_global_data[294].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpi_global_data[294].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

}
