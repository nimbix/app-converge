#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <cstring>
#include <execinfo.h>
#include <dlfcn.h>
#include <cstdarg>
#ifdef __SELFIE_POSIXIO_HOOK__
#include <cstdio>
#endif
#ifdef __SELFIE_POSIXIO_BUILTIN__
#include <fenv.h>

#pragma STDC FENV_ACCESS ON

typedef void * (*function_type)();
#endif


/// \brief Total number of MPI functions
#define N_POSIXIO_FUNCTIONS 37

/// \brief Return a string containing name of functions
/// \param[in] i Index
/// \return   Return a string containing name of functions
///
char *selfie_get_posixio_function_name(int i)
{
    char const *posixio_functions_name[] = {
      "fdopen",
      "fopen",
      "freopen",
      "close",
      "creat",
      "fclose",
      "fdatasync",
      "fflush",
      "fgetc",
      "fgetpos",
      "fseek",
      "fsetpos",
      "fsync",
      "ftruncate64",
      "ftruncate",
      "getc",
      "open64",
      "open",
      "truncate64",
      "truncate",
      "ungetc",
      "ftell",
      "lseek64",
      "lseek",
      "fread",
      "fwrite",
      "pread",
      "preadv",
      "pwrite",
      "pwritev",
      "read",
      "readv",
      "write",
      "writev",
      "rewind",
      "fcntl",
      "ioctl",
      NULL
    };
    return strdup(posixio_functions_name[i]);
};

/// \brief Array of pointers of functions
void *selfie_orig_pointer_functions[37] = {NULL};

/// \brief Array of pointers of functions
void **selfie_pointer_functions = selfie_orig_pointer_functions;


#ifdef __SELFIE_POSIXIO_HOOK__
typedef FILE* (*orig_fdopen_f_type)( int fd,  const char * mode);
typedef FILE* (*orig_fopen_f_type)( const char * path,  const char * mode);
typedef FILE* (*orig_freopen_f_type)( const char * path,  const char * mode,  FILE * stream);
typedef int (*orig_close_f_type)( int fd);
typedef int (*orig_creat_f_type)( const char * pathname,  mode_t mode);
typedef int (*orig_fclose_f_type)( FILE * fp);
typedef int (*orig_fdatasync_f_type)( int fd);
typedef int (*orig_fflush_f_type)( FILE * stream);
typedef int (*orig_fgetc_f_type)( FILE * stream);
typedef int (*orig_fgetpos_f_type)( FILE * stream,  fpos_t * pos);
typedef int (*orig_fseek_f_type)( FILE * stream,  long offset,  int whence);
typedef int (*orig_fsetpos_f_type)( FILE * stream,  const fpos_t * pos);
typedef int (*orig_fsync_f_type)( int fd);
typedef int (*orig_ftruncate64_f_type)( int fd,  off64_t length);
typedef int (*orig_ftruncate_f_type)( int fd,  off_t length);
typedef int (*orig_getc_f_type)( FILE * stream);
typedef int (*orig_open64_f_type)( const char * pathname,  int flags,  mode_t mode);
typedef int (*orig_open_f_type)( const char * pathname,  int flags,  mode_t mode);
typedef int (*orig_truncate64_f_type)( const char * path,  off64_t length);
typedef int (*orig_truncate_f_type)( const char * path,  off_t length);
typedef int (*orig_ungetc_f_type)( int c,  FILE * stream);
typedef long (*orig_ftell_f_type)( FILE * stream);
typedef off64_t (*orig_lseek64_f_type)( int fd,  off64_t offset,  int whence);
typedef off_t (*orig_lseek_f_type)( int fd,  off_t offset,  int whence);
typedef size_t (*orig_fread_f_type)( void * ptr,  size_t size,  size_t nmemb,  FILE * stream);
typedef size_t (*orig_fwrite_f_type)( const void * ptr,  size_t size,  size_t nmemb,  FILE * stream);
typedef ssize_t (*orig_pread_f_type)( int fd,  void * buf,  size_t count,  off_t offset);
typedef ssize_t (*orig_preadv_f_type)( int fd,  const struct iovec * iov,  int iovcnt,  off_t offset);
typedef ssize_t (*orig_pwrite_f_type)( int fd,  const void * buf,  size_t count,  off_t offset);
typedef ssize_t (*orig_pwritev_f_type)( int fd,  const struct iovec * iov,  int iovcnt,  off_t offset);
typedef ssize_t (*orig_read_f_type)( int fd,  void * buf,  size_t count);
typedef ssize_t (*orig_readv_f_type)( int fd,  const struct iovec * iov,  int iovcnt);
typedef ssize_t (*orig_write_f_type)( int fd,  const void * buf,  size_t count);
typedef ssize_t (*orig_writev_f_type)( int fd,  const struct iovec * iov,  int iovcnt);
typedef void (*orig_rewind_f_type)( FILE * stream);
typedef int (*orig_fcntl_f_type)( int fd,  int cmd,  long arg);
typedef int (*orig_ioctl_f_type)( int fd,  unsigned long request,  void * argp);
#endif

extern "C" {


#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fdopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* fdopen(...)
{
    int ap_except = 0;
    FILE* val = (FILE*) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[0];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fdopen");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fdopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* selfie_fdopen(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    FILE* val = (FILE*) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[0];

    selfie_posixio_global_data[0].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[0].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fdopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* fdopen( int fd,  const char * mode)
{
    FILE* val = (FILE*) 0;

    orig_fdopen_f_type selfie_function = NULL;

    selfie_function = (orig_fdopen_f_type) selfie_pointer_functions[0];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fdopen_f_type) dlsym(RTLD_NEXT,"fdopen");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, mode);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fdopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* selfie_fdopen( int fd,  const char * mode)
{
    double f_start = 0.0;
    FILE* val = (FILE*) 0; 

    orig_fdopen_f_type selfie_function = NULL;
    selfie_function = (orig_fdopen_f_type) selfie_orig_pointer_functions[0];

    selfie_posixio_global_data[0].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, mode);
    selfie_posixio_global_data[0].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* fopen(...)
{
    int ap_except = 0;
    FILE* val = (FILE*) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[1];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fopen");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* selfie_fopen(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    FILE* val = (FILE*) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[1];

    selfie_posixio_global_data[1].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[1].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* fopen( const char * path,  const char * mode)
{
    FILE* val = (FILE*) 0;

    orig_fopen_f_type selfie_function = NULL;

    selfie_function = (orig_fopen_f_type) selfie_pointer_functions[1];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fopen_f_type) dlsym(RTLD_NEXT,"fopen");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(path, mode);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* selfie_fopen( const char * path,  const char * mode)
{
    double f_start = 0.0;
    FILE* val = (FILE*) 0; 

    orig_fopen_f_type selfie_function = NULL;
    selfie_function = (orig_fopen_f_type) selfie_orig_pointer_functions[1];

    selfie_posixio_global_data[1].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(path, mode);
    selfie_posixio_global_data[1].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief freopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* freopen(...)
{
    int ap_except = 0;
    FILE* val = (FILE*) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[2];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"freopen");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_freopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* selfie_freopen(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    FILE* val = (FILE*) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[2];

    selfie_posixio_global_data[2].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[2].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief freopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* freopen( const char * path,  const char * mode,  FILE * stream)
{
    FILE* val = (FILE*) 0;

    orig_freopen_f_type selfie_function = NULL;

    selfie_function = (orig_freopen_f_type) selfie_pointer_functions[2];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_freopen_f_type) dlsym(RTLD_NEXT,"freopen");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(path, mode, stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_freopen
///
/// \param ...
/// \return FILE*
///
/// \details
///
FILE* selfie_freopen( const char * path,  const char * mode,  FILE * stream)
{
    double f_start = 0.0;
    FILE* val = (FILE*) 0; 

    orig_freopen_f_type selfie_function = NULL;
    selfie_function = (orig_freopen_f_type) selfie_orig_pointer_functions[2];

    selfie_posixio_global_data[2].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(path, mode, stream);
    selfie_posixio_global_data[2].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief close
///
/// \param ...
/// \return int
///
/// \details
///
int close(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[3];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"close");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_close
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_close(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[3];

    selfie_posixio_global_data[3].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[3].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief close
///
/// \param ...
/// \return int
///
/// \details
///
int close( int fd)
{
    int val = (int) 0;

    orig_close_f_type selfie_function = NULL;

    selfie_function = (orig_close_f_type) selfie_pointer_functions[3];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_close_f_type) dlsym(RTLD_NEXT,"close");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_close
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_close( int fd)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_close_f_type selfie_function = NULL;
    selfie_function = (orig_close_f_type) selfie_orig_pointer_functions[3];

    selfie_posixio_global_data[3].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd);
    selfie_posixio_global_data[3].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief creat
///
/// \param ...
/// \return int
///
/// \details
///
int creat(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[4];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"creat");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_creat
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_creat(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[4];

    selfie_posixio_global_data[4].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[4].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief creat
///
/// \param ...
/// \return int
///
/// \details
///
int creat( const char * pathname,  mode_t mode)
{
    int val = (int) 0;

    orig_creat_f_type selfie_function = NULL;

    selfie_function = (orig_creat_f_type) selfie_pointer_functions[4];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_creat_f_type) dlsym(RTLD_NEXT,"creat");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(pathname, mode);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_creat
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_creat( const char * pathname,  mode_t mode)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_creat_f_type selfie_function = NULL;
    selfie_function = (orig_creat_f_type) selfie_orig_pointer_functions[4];

    selfie_posixio_global_data[4].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(pathname, mode);
    selfie_posixio_global_data[4].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fclose
///
/// \param ...
/// \return int
///
/// \details
///
int fclose(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[5];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fclose");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fclose
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fclose(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[5];

    selfie_posixio_global_data[5].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[5].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fclose
///
/// \param ...
/// \return int
///
/// \details
///
int fclose( FILE * fp)
{
    int val = (int) 0;

    orig_fclose_f_type selfie_function = NULL;

    selfie_function = (orig_fclose_f_type) selfie_pointer_functions[5];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fclose_f_type) dlsym(RTLD_NEXT,"fclose");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fp);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fclose
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fclose( FILE * fp)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fclose_f_type selfie_function = NULL;
    selfie_function = (orig_fclose_f_type) selfie_orig_pointer_functions[5];

    selfie_posixio_global_data[5].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fp);
    selfie_posixio_global_data[5].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fdatasync
///
/// \param ...
/// \return int
///
/// \details
///
int fdatasync(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[6];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fdatasync");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fdatasync
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fdatasync(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[6];

    selfie_posixio_global_data[6].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[6].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fdatasync
///
/// \param ...
/// \return int
///
/// \details
///
int fdatasync( int fd)
{
    int val = (int) 0;

    orig_fdatasync_f_type selfie_function = NULL;

    selfie_function = (orig_fdatasync_f_type) selfie_pointer_functions[6];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fdatasync_f_type) dlsym(RTLD_NEXT,"fdatasync");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fdatasync
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fdatasync( int fd)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fdatasync_f_type selfie_function = NULL;
    selfie_function = (orig_fdatasync_f_type) selfie_orig_pointer_functions[6];

    selfie_posixio_global_data[6].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd);
    selfie_posixio_global_data[6].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fflush
///
/// \param ...
/// \return int
///
/// \details
///
int fflush(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[7];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fflush");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fflush
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fflush(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[7];

    selfie_posixio_global_data[7].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[7].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fflush
///
/// \param ...
/// \return int
///
/// \details
///
int fflush( FILE * stream)
{
    int val = (int) 0;

    orig_fflush_f_type selfie_function = NULL;

    selfie_function = (orig_fflush_f_type) selfie_pointer_functions[7];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fflush_f_type) dlsym(RTLD_NEXT,"fflush");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fflush
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fflush( FILE * stream)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fflush_f_type selfie_function = NULL;
    selfie_function = (orig_fflush_f_type) selfie_orig_pointer_functions[7];

    selfie_posixio_global_data[7].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream);
    selfie_posixio_global_data[7].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fgetc
///
/// \param ...
/// \return int
///
/// \details
///
int fgetc(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[8];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fgetc");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fgetc
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fgetc(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[8];

    selfie_posixio_global_data[8].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[8].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fgetc
///
/// \param ...
/// \return int
///
/// \details
///
int fgetc( FILE * stream)
{
    int val = (int) 0;

    orig_fgetc_f_type selfie_function = NULL;

    selfie_function = (orig_fgetc_f_type) selfie_pointer_functions[8];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fgetc_f_type) dlsym(RTLD_NEXT,"fgetc");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fgetc
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fgetc( FILE * stream)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fgetc_f_type selfie_function = NULL;
    selfie_function = (orig_fgetc_f_type) selfie_orig_pointer_functions[8];

    selfie_posixio_global_data[8].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream);
    selfie_posixio_global_data[8].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fgetpos
///
/// \param ...
/// \return int
///
/// \details
///
int fgetpos(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[9];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fgetpos");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fgetpos
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fgetpos(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[9];

    selfie_posixio_global_data[9].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[9].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fgetpos
///
/// \param ...
/// \return int
///
/// \details
///
int fgetpos( FILE * stream,  fpos_t * pos)
{
    int val = (int) 0;

    orig_fgetpos_f_type selfie_function = NULL;

    selfie_function = (orig_fgetpos_f_type) selfie_pointer_functions[9];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fgetpos_f_type) dlsym(RTLD_NEXT,"fgetpos");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream, pos);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fgetpos
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fgetpos( FILE * stream,  fpos_t * pos)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fgetpos_f_type selfie_function = NULL;
    selfie_function = (orig_fgetpos_f_type) selfie_orig_pointer_functions[9];

    selfie_posixio_global_data[9].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream, pos);
    selfie_posixio_global_data[9].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fseek
///
/// \param ...
/// \return int
///
/// \details
///
int fseek(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[10];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fseek");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fseek
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fseek(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[10];

    selfie_posixio_global_data[10].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[10].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fseek
///
/// \param ...
/// \return int
///
/// \details
///
int fseek( FILE * stream,  long offset,  int whence)
{
    int val = (int) 0;

    orig_fseek_f_type selfie_function = NULL;

    selfie_function = (orig_fseek_f_type) selfie_pointer_functions[10];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fseek_f_type) dlsym(RTLD_NEXT,"fseek");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream, offset, whence);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fseek
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fseek( FILE * stream,  long offset,  int whence)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fseek_f_type selfie_function = NULL;
    selfie_function = (orig_fseek_f_type) selfie_orig_pointer_functions[10];

    selfie_posixio_global_data[10].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream, offset, whence);
    selfie_posixio_global_data[10].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fsetpos
///
/// \param ...
/// \return int
///
/// \details
///
int fsetpos(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[11];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fsetpos");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fsetpos
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fsetpos(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[11];

    selfie_posixio_global_data[11].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[11].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fsetpos
///
/// \param ...
/// \return int
///
/// \details
///
int fsetpos( FILE * stream,  const fpos_t * pos)
{
    int val = (int) 0;

    orig_fsetpos_f_type selfie_function = NULL;

    selfie_function = (orig_fsetpos_f_type) selfie_pointer_functions[11];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fsetpos_f_type) dlsym(RTLD_NEXT,"fsetpos");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream, pos);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fsetpos
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fsetpos( FILE * stream,  const fpos_t * pos)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fsetpos_f_type selfie_function = NULL;
    selfie_function = (orig_fsetpos_f_type) selfie_orig_pointer_functions[11];

    selfie_posixio_global_data[11].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream, pos);
    selfie_posixio_global_data[11].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fsync
///
/// \param ...
/// \return int
///
/// \details
///
int fsync(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[12];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fsync");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fsync
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fsync(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[12];

    selfie_posixio_global_data[12].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[12].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fsync
///
/// \param ...
/// \return int
///
/// \details
///
int fsync( int fd)
{
    int val = (int) 0;

    orig_fsync_f_type selfie_function = NULL;

    selfie_function = (orig_fsync_f_type) selfie_pointer_functions[12];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fsync_f_type) dlsym(RTLD_NEXT,"fsync");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fsync
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fsync( int fd)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fsync_f_type selfie_function = NULL;
    selfie_function = (orig_fsync_f_type) selfie_orig_pointer_functions[12];

    selfie_posixio_global_data[12].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd);
    selfie_posixio_global_data[12].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief ftruncate64
///
/// \param ...
/// \return int
///
/// \details
///
int ftruncate64(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[13];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"ftruncate64");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_ftruncate64
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ftruncate64(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[13];

    selfie_posixio_global_data[13].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[13].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief ftruncate64
///
/// \param ...
/// \return int
///
/// \details
///
int ftruncate64( int fd,  off64_t length)
{
    int val = (int) 0;

    orig_ftruncate64_f_type selfie_function = NULL;

    selfie_function = (orig_ftruncate64_f_type) selfie_pointer_functions[13];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_ftruncate64_f_type) dlsym(RTLD_NEXT,"ftruncate64");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, length);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_ftruncate64
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ftruncate64( int fd,  off64_t length)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_ftruncate64_f_type selfie_function = NULL;
    selfie_function = (orig_ftruncate64_f_type) selfie_orig_pointer_functions[13];

    selfie_posixio_global_data[13].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, length);
    selfie_posixio_global_data[13].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief ftruncate
///
/// \param ...
/// \return int
///
/// \details
///
int ftruncate(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[14];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"ftruncate");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_ftruncate
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ftruncate(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[14];

    selfie_posixio_global_data[14].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[14].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief ftruncate
///
/// \param ...
/// \return int
///
/// \details
///
int ftruncate( int fd,  off_t length)
{
    int val = (int) 0;

    orig_ftruncate_f_type selfie_function = NULL;

    selfie_function = (orig_ftruncate_f_type) selfie_pointer_functions[14];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_ftruncate_f_type) dlsym(RTLD_NEXT,"ftruncate");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, length);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_ftruncate
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ftruncate( int fd,  off_t length)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_ftruncate_f_type selfie_function = NULL;
    selfie_function = (orig_ftruncate_f_type) selfie_orig_pointer_functions[14];

    selfie_posixio_global_data[14].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, length);
    selfie_posixio_global_data[14].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief getc
///
/// \param ...
/// \return int
///
/// \details
///
int getc(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[15];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"getc");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_getc
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_getc(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[15];

    selfie_posixio_global_data[15].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[15].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief getc
///
/// \param ...
/// \return int
///
/// \details
///
int getc( FILE * stream)
{
    int val = (int) 0;

    orig_getc_f_type selfie_function = NULL;

    selfie_function = (orig_getc_f_type) selfie_pointer_functions[15];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_getc_f_type) dlsym(RTLD_NEXT,"getc");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_getc
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_getc( FILE * stream)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_getc_f_type selfie_function = NULL;
    selfie_function = (orig_getc_f_type) selfie_orig_pointer_functions[15];

    selfie_posixio_global_data[15].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream);
    selfie_posixio_global_data[15].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief open64
///
/// \param ...
/// \return int
///
/// \details
///
int open64(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[16];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"open64");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_open64
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_open64(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[16];

    selfie_posixio_global_data[16].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[16].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief open64
///
/// \param ...
/// \return int
///
/// \details
///
int open64( const char * pathname,  int flags,  mode_t mode)
{
    int val = (int) 0;

    orig_open64_f_type selfie_function = NULL;

    selfie_function = (orig_open64_f_type) selfie_pointer_functions[16];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_open64_f_type) dlsym(RTLD_NEXT,"open64");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(pathname, flags, mode);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_open64
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_open64( const char * pathname,  int flags,  mode_t mode)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_open64_f_type selfie_function = NULL;
    selfie_function = (orig_open64_f_type) selfie_orig_pointer_functions[16];

    selfie_posixio_global_data[16].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(pathname, flags, mode);
    selfie_posixio_global_data[16].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief open
///
/// \param ...
/// \return int
///
/// \details
///
int open(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[17];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"open");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_open
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_open(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[17];

    selfie_posixio_global_data[17].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[17].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief open
///
/// \param ...
/// \return int
///
/// \details
///
int open( const char * pathname,  int flags,  mode_t mode)
{
    int val = (int) 0;

    orig_open_f_type selfie_function = NULL;

    selfie_function = (orig_open_f_type) selfie_pointer_functions[17];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_open_f_type) dlsym(RTLD_NEXT,"open");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(pathname, flags, mode);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_open
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_open( const char * pathname,  int flags,  mode_t mode)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_open_f_type selfie_function = NULL;
    selfie_function = (orig_open_f_type) selfie_orig_pointer_functions[17];

    selfie_posixio_global_data[17].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(pathname, flags, mode);
    selfie_posixio_global_data[17].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief truncate64
///
/// \param ...
/// \return int
///
/// \details
///
int truncate64(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[18];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"truncate64");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_truncate64
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_truncate64(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[18];

    selfie_posixio_global_data[18].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[18].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief truncate64
///
/// \param ...
/// \return int
///
/// \details
///
int truncate64( const char * path,  off64_t length)
{
    int val = (int) 0;

    orig_truncate64_f_type selfie_function = NULL;

    selfie_function = (orig_truncate64_f_type) selfie_pointer_functions[18];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_truncate64_f_type) dlsym(RTLD_NEXT,"truncate64");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(path, length);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_truncate64
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_truncate64( const char * path,  off64_t length)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_truncate64_f_type selfie_function = NULL;
    selfie_function = (orig_truncate64_f_type) selfie_orig_pointer_functions[18];

    selfie_posixio_global_data[18].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(path, length);
    selfie_posixio_global_data[18].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief truncate
///
/// \param ...
/// \return int
///
/// \details
///
int truncate(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[19];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"truncate");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_truncate
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_truncate(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[19];

    selfie_posixio_global_data[19].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[19].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief truncate
///
/// \param ...
/// \return int
///
/// \details
///
int truncate( const char * path,  off_t length)
{
    int val = (int) 0;

    orig_truncate_f_type selfie_function = NULL;

    selfie_function = (orig_truncate_f_type) selfie_pointer_functions[19];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_truncate_f_type) dlsym(RTLD_NEXT,"truncate");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(path, length);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_truncate
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_truncate( const char * path,  off_t length)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_truncate_f_type selfie_function = NULL;
    selfie_function = (orig_truncate_f_type) selfie_orig_pointer_functions[19];

    selfie_posixio_global_data[19].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(path, length);
    selfie_posixio_global_data[19].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief ungetc
///
/// \param ...
/// \return int
///
/// \details
///
int ungetc(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[20];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"ungetc");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_ungetc
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ungetc(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[20];

    selfie_posixio_global_data[20].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[20].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief ungetc
///
/// \param ...
/// \return int
///
/// \details
///
int ungetc( int c,  FILE * stream)
{
    int val = (int) 0;

    orig_ungetc_f_type selfie_function = NULL;

    selfie_function = (orig_ungetc_f_type) selfie_pointer_functions[20];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_ungetc_f_type) dlsym(RTLD_NEXT,"ungetc");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(c, stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_ungetc
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ungetc( int c,  FILE * stream)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_ungetc_f_type selfie_function = NULL;
    selfie_function = (orig_ungetc_f_type) selfie_orig_pointer_functions[20];

    selfie_posixio_global_data[20].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(c, stream);
    selfie_posixio_global_data[20].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief ftell
///
/// \param ...
/// \return long
///
/// \details
///
long ftell(...)
{
    int ap_except = 0;
    long val = (long) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[21];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"ftell");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_ftell
///
/// \param ...
/// \return long
///
/// \details
///
long selfie_ftell(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    long val = (long) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[21];

    selfie_posixio_global_data[21].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[21].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief ftell
///
/// \param ...
/// \return long
///
/// \details
///
long ftell( FILE * stream)
{
    long val = (long) 0;

    orig_ftell_f_type selfie_function = NULL;

    selfie_function = (orig_ftell_f_type) selfie_pointer_functions[21];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_ftell_f_type) dlsym(RTLD_NEXT,"ftell");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_ftell
///
/// \param ...
/// \return long
///
/// \details
///
long selfie_ftell( FILE * stream)
{
    double f_start = 0.0;
    long val = (long) 0; 

    orig_ftell_f_type selfie_function = NULL;
    selfie_function = (orig_ftell_f_type) selfie_orig_pointer_functions[21];

    selfie_posixio_global_data[21].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(stream);
    selfie_posixio_global_data[21].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief lseek64
///
/// \param ...
/// \return off64_t
///
/// \details
///
off64_t lseek64(...)
{
    int ap_except = 0;
    off64_t val = (off64_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[22];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"lseek64");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_lseek64
///
/// \param ...
/// \return off64_t
///
/// \details
///
off64_t selfie_lseek64(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    off64_t val = (off64_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[22];

    selfie_posixio_global_data[22].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[22].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief lseek64
///
/// \param ...
/// \return off64_t
///
/// \details
///
off64_t lseek64( int fd,  off64_t offset,  int whence)
{
    off64_t val = (off64_t) 0;

    orig_lseek64_f_type selfie_function = NULL;

    selfie_function = (orig_lseek64_f_type) selfie_pointer_functions[22];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_lseek64_f_type) dlsym(RTLD_NEXT,"lseek64");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, offset, whence);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_lseek64
///
/// \param ...
/// \return off64_t
///
/// \details
///
off64_t selfie_lseek64( int fd,  off64_t offset,  int whence)
{
    double f_start = 0.0;
    off64_t val = (off64_t) 0; 

    orig_lseek64_f_type selfie_function = NULL;
    selfie_function = (orig_lseek64_f_type) selfie_orig_pointer_functions[22];

    selfie_posixio_global_data[22].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, offset, whence);
    selfie_posixio_global_data[22].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief lseek
///
/// \param ...
/// \return off_t
///
/// \details
///
off_t lseek(...)
{
    int ap_except = 0;
    off_t val = (off_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[23];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"lseek");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_lseek
///
/// \param ...
/// \return off_t
///
/// \details
///
off_t selfie_lseek(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    off_t val = (off_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[23];

    selfie_posixio_global_data[23].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[23].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief lseek
///
/// \param ...
/// \return off_t
///
/// \details
///
off_t lseek( int fd,  off_t offset,  int whence)
{
    off_t val = (off_t) 0;

    orig_lseek_f_type selfie_function = NULL;

    selfie_function = (orig_lseek_f_type) selfie_pointer_functions[23];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_lseek_f_type) dlsym(RTLD_NEXT,"lseek");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, offset, whence);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_lseek
///
/// \param ...
/// \return off_t
///
/// \details
///
off_t selfie_lseek( int fd,  off_t offset,  int whence)
{
    double f_start = 0.0;
    off_t val = (off_t) 0; 

    orig_lseek_f_type selfie_function = NULL;
    selfie_function = (orig_lseek_f_type) selfie_orig_pointer_functions[23];

    selfie_posixio_global_data[23].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, offset, whence);
    selfie_posixio_global_data[23].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fread
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t fread(...)
{
    int ap_except = 0;
    size_t val = (size_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[24];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fread");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fread
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t selfie_fread(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    size_t val = (size_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[24];

    selfie_posixio_global_data[24].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[24].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fread
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t fread( void * ptr,  size_t size,  size_t nmemb,  FILE * stream)
{
    size_t val = (size_t) 0;

    orig_fread_f_type selfie_function = NULL;

    selfie_function = (orig_fread_f_type) selfie_pointer_functions[24];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fread_f_type) dlsym(RTLD_NEXT,"fread");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(ptr, size, nmemb, stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fread
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t selfie_fread( void * ptr,  size_t size,  size_t nmemb,  FILE * stream)
{
    double f_start = 0.0;
    size_t val = (size_t) 0; 

    orig_fread_f_type selfie_function = NULL;
    selfie_function = (orig_fread_f_type) selfie_orig_pointer_functions[24];

    selfie_posixio_global_data[24].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(ptr, size, nmemb, stream);
    selfie_posixio_global_data[24].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fwrite
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t fwrite(...)
{
    int ap_except = 0;
    size_t val = (size_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[25];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fwrite");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fwrite
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t selfie_fwrite(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    size_t val = (size_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[25];

    selfie_posixio_global_data[25].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[25].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fwrite
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t fwrite( const void * ptr,  size_t size,  size_t nmemb,  FILE * stream)
{
    size_t val = (size_t) 0;

    orig_fwrite_f_type selfie_function = NULL;

    selfie_function = (orig_fwrite_f_type) selfie_pointer_functions[25];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fwrite_f_type) dlsym(RTLD_NEXT,"fwrite");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(ptr, size, nmemb, stream);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fwrite
///
/// \param ...
/// \return size_t
///
/// \details
///
size_t selfie_fwrite( const void * ptr,  size_t size,  size_t nmemb,  FILE * stream)
{
    double f_start = 0.0;
    size_t val = (size_t) 0; 

    orig_fwrite_f_type selfie_function = NULL;
    selfie_function = (orig_fwrite_f_type) selfie_orig_pointer_functions[25];

    selfie_posixio_global_data[25].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(ptr, size, nmemb, stream);
    selfie_posixio_global_data[25].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief pread
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t pread(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[26];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"pread");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_pread
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_pread(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[26];

    selfie_posixio_global_data[26].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[26].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief pread
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t pread( int fd,  void * buf,  size_t count,  off_t offset)
{
    ssize_t val = (ssize_t) 0;

    orig_pread_f_type selfie_function = NULL;

    selfie_function = (orig_pread_f_type) selfie_pointer_functions[26];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_pread_f_type) dlsym(RTLD_NEXT,"pread");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, buf, count, offset);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_pread
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_pread( int fd,  void * buf,  size_t count,  off_t offset)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_pread_f_type selfie_function = NULL;
    selfie_function = (orig_pread_f_type) selfie_orig_pointer_functions[26];

    selfie_posixio_global_data[26].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, buf, count, offset);
    selfie_posixio_global_data[26].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief preadv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t preadv(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[27];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"preadv");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_preadv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_preadv(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[27];

    selfie_posixio_global_data[27].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[27].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief preadv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t preadv( int fd,  const struct iovec * iov,  int iovcnt,  off_t offset)
{
    ssize_t val = (ssize_t) 0;

    orig_preadv_f_type selfie_function = NULL;

    selfie_function = (orig_preadv_f_type) selfie_pointer_functions[27];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_preadv_f_type) dlsym(RTLD_NEXT,"preadv");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, iov, iovcnt, offset);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_preadv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_preadv( int fd,  const struct iovec * iov,  int iovcnt,  off_t offset)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_preadv_f_type selfie_function = NULL;
    selfie_function = (orig_preadv_f_type) selfie_orig_pointer_functions[27];

    selfie_posixio_global_data[27].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, iov, iovcnt, offset);
    selfie_posixio_global_data[27].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief pwrite
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t pwrite(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[28];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"pwrite");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_pwrite
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_pwrite(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[28];

    selfie_posixio_global_data[28].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[28].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief pwrite
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t pwrite( int fd,  const void * buf,  size_t count,  off_t offset)
{
    ssize_t val = (ssize_t) 0;

    orig_pwrite_f_type selfie_function = NULL;

    selfie_function = (orig_pwrite_f_type) selfie_pointer_functions[28];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_pwrite_f_type) dlsym(RTLD_NEXT,"pwrite");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, buf, count, offset);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_pwrite
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_pwrite( int fd,  const void * buf,  size_t count,  off_t offset)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_pwrite_f_type selfie_function = NULL;
    selfie_function = (orig_pwrite_f_type) selfie_orig_pointer_functions[28];

    selfie_posixio_global_data[28].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, buf, count, offset);
    selfie_posixio_global_data[28].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief pwritev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t pwritev(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[29];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"pwritev");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_pwritev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_pwritev(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[29];

    selfie_posixio_global_data[29].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[29].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief pwritev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t pwritev( int fd,  const struct iovec * iov,  int iovcnt,  off_t offset)
{
    ssize_t val = (ssize_t) 0;

    orig_pwritev_f_type selfie_function = NULL;

    selfie_function = (orig_pwritev_f_type) selfie_pointer_functions[29];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_pwritev_f_type) dlsym(RTLD_NEXT,"pwritev");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, iov, iovcnt, offset);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_pwritev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_pwritev( int fd,  const struct iovec * iov,  int iovcnt,  off_t offset)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_pwritev_f_type selfie_function = NULL;
    selfie_function = (orig_pwritev_f_type) selfie_orig_pointer_functions[29];

    selfie_posixio_global_data[29].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, iov, iovcnt, offset);
    selfie_posixio_global_data[29].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief read
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t read(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[30];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"read");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_read
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_read(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[30];

    selfie_posixio_global_data[30].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[30].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief read
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t read( int fd,  void * buf,  size_t count)
{
    ssize_t val = (ssize_t) 0;

    orig_read_f_type selfie_function = NULL;

    selfie_function = (orig_read_f_type) selfie_pointer_functions[30];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_read_f_type) dlsym(RTLD_NEXT,"read");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, buf, count);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_read
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_read( int fd,  void * buf,  size_t count)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_read_f_type selfie_function = NULL;
    selfie_function = (orig_read_f_type) selfie_orig_pointer_functions[30];

    selfie_posixio_global_data[30].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, buf, count);
    selfie_posixio_global_data[30].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief readv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t readv(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[31];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"readv");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_readv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_readv(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[31];

    selfie_posixio_global_data[31].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[31].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief readv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t readv( int fd,  const struct iovec * iov,  int iovcnt)
{
    ssize_t val = (ssize_t) 0;

    orig_readv_f_type selfie_function = NULL;

    selfie_function = (orig_readv_f_type) selfie_pointer_functions[31];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_readv_f_type) dlsym(RTLD_NEXT,"readv");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, iov, iovcnt);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_readv
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_readv( int fd,  const struct iovec * iov,  int iovcnt)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_readv_f_type selfie_function = NULL;
    selfie_function = (orig_readv_f_type) selfie_orig_pointer_functions[31];

    selfie_posixio_global_data[31].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, iov, iovcnt);
    selfie_posixio_global_data[31].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief write
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t write(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[32];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"write");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_write
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_write(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[32];

    selfie_posixio_global_data[32].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[32].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief write
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t write( int fd,  const void * buf,  size_t count)
{
    ssize_t val = (ssize_t) 0;

    orig_write_f_type selfie_function = NULL;

    selfie_function = (orig_write_f_type) selfie_pointer_functions[32];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_write_f_type) dlsym(RTLD_NEXT,"write");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, buf, count);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_write
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_write( int fd,  const void * buf,  size_t count)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_write_f_type selfie_function = NULL;
    selfie_function = (orig_write_f_type) selfie_orig_pointer_functions[32];

    selfie_posixio_global_data[32].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, buf, count);
    selfie_posixio_global_data[32].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief writev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t writev(...)
{
    int ap_except = 0;
    ssize_t val = (ssize_t) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[33];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"writev");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_writev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_writev(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    ssize_t val = (ssize_t) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[33];

    selfie_posixio_global_data[33].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[33].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief writev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t writev( int fd,  const struct iovec * iov,  int iovcnt)
{
    ssize_t val = (ssize_t) 0;

    orig_writev_f_type selfie_function = NULL;

    selfie_function = (orig_writev_f_type) selfie_pointer_functions[33];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_writev_f_type) dlsym(RTLD_NEXT,"writev");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, iov, iovcnt);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_writev
///
/// \param ...
/// \return ssize_t
///
/// \details
///
ssize_t selfie_writev( int fd,  const struct iovec * iov,  int iovcnt)
{
    double f_start = 0.0;
    ssize_t val = (ssize_t) 0; 

    orig_writev_f_type selfie_function = NULL;
    selfie_function = (orig_writev_f_type) selfie_orig_pointer_functions[33];

    selfie_posixio_global_data[33].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, iov, iovcnt);
    selfie_posixio_global_data[33].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief rewind
///
/// \param ...
/// \return void
///
/// \details
///
void rewind(...)
{
    int ap_except = 0;
    

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[34];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"rewind");
       if(selfie_function == NULL) return;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_rewind
///
/// \param ...
/// \return void
///
/// \details
///
void selfie_rewind(...)
{
    double f_start = 0.0;
    int ap_except = 0;
     

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[34];

    selfie_posixio_global_data[34].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[34].function_time += selfie_mysecond() - f_start;
   
    return;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief rewind
///
/// \param ...
/// \return void
///
/// \details
///
void rewind( FILE * stream)
{
    

    orig_rewind_f_type selfie_function = NULL;

    selfie_function = (orig_rewind_f_type) selfie_pointer_functions[34];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_rewind_f_type) dlsym(RTLD_NEXT,"rewind");
       if(selfie_function == NULL) return;
    }
    selfie_function(stream);
    return;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_rewind
///
/// \param ...
/// \return void
///
/// \details
///
void selfie_rewind( FILE * stream)
{
    double f_start = 0.0;
     

    orig_rewind_f_type selfie_function = NULL;
    selfie_function = (orig_rewind_f_type) selfie_orig_pointer_functions[34];

    selfie_posixio_global_data[34].function_count++;
    f_start = selfie_mysecond();
    selfie_function(stream);
    selfie_posixio_global_data[34].function_time += selfie_mysecond() - f_start;
   
    return;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief fcntl
///
/// \param ...
/// \return int
///
/// \details
///
int fcntl(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[35];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"fcntl");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_fcntl
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fcntl(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[35];

    selfie_posixio_global_data[35].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[35].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief fcntl
///
/// \param ...
/// \return int
///
/// \details
///
int fcntl( int fd,  int cmd,  long arg)
{
    int val = (int) 0;

    orig_fcntl_f_type selfie_function = NULL;

    selfie_function = (orig_fcntl_f_type) selfie_pointer_functions[35];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_fcntl_f_type) dlsym(RTLD_NEXT,"fcntl");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, cmd, arg);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_fcntl
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_fcntl( int fd,  int cmd,  long arg)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_fcntl_f_type selfie_function = NULL;
    selfie_function = (orig_fcntl_f_type) selfie_orig_pointer_functions[35];

    selfie_posixio_global_data[35].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, cmd, arg);
    selfie_posixio_global_data[35].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief ioctl
///
/// \param ...
/// \return int
///
/// \details
///
int ioctl(...)
{
    int ap_except = 0;
    int val = (int) 0;

    function_type selfie_function = NULL;

    selfie_function = (function_type) selfie_pointer_functions[36];
    
    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"ioctl");
       if(selfie_function == NULL) return val;
    }

    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
};
#endif

#ifdef __SELFIE_POSIXIO_BUILTIN__
/// \brief selfie_ioctl
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ioctl(...)
{
    double f_start = 0.0;
    int ap_except = 0;
    int val = (int) 0; 

    function_type selfie_function = NULL;
    selfie_function = (function_type) selfie_orig_pointer_functions[36];

    selfie_posixio_global_data[36].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply((void (*)(...))selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    __builtin_return(ret);
    selfie_posixio_global_data[36].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief ioctl
///
/// \param ...
/// \return int
///
/// \details
///
int ioctl( int fd,  unsigned long request,  void * argp)
{
    int val = (int) 0;

    orig_ioctl_f_type selfie_function = NULL;

    selfie_function = (orig_ioctl_f_type) selfie_pointer_functions[36];
    
    if(selfie_function == NULL)
    {
       selfie_function = (orig_ioctl_f_type) dlsym(RTLD_NEXT,"ioctl");
       if(selfie_function == NULL) return val;
    }
    val = selfie_function(fd, request, argp);
    return val;
};
#endif

#ifdef __SELFIE_POSIXIO_HOOK__
/// \brief selfie_ioctl
///
/// \param ...
/// \return int
///
/// \details
///
int selfie_ioctl( int fd,  unsigned long request,  void * argp)
{
    double f_start = 0.0;
    int val = (int) 0; 

    orig_ioctl_f_type selfie_function = NULL;
    selfie_function = (orig_ioctl_f_type) selfie_orig_pointer_functions[36];

    selfie_posixio_global_data[36].function_count++;
    f_start = selfie_mysecond();
    val = selfie_function(fd, request, argp);
    selfie_posixio_global_data[36].function_time += selfie_mysecond() - f_start;
   
    return val;
};
#endif

/// \brief custom functions
void *selfie_new_pointer_functions[] = {
      (void *) selfie_fdopen,
      (void *) selfie_fopen,
      (void *) selfie_freopen,
      (void *) selfie_close,
      (void *) selfie_creat,
      (void *) selfie_fclose,
      (void *) selfie_fdatasync,
      (void *) selfie_fflush,
      (void *) selfie_fgetc,
      (void *) selfie_fgetpos,
      (void *) selfie_fseek,
      (void *) selfie_fsetpos,
      (void *) selfie_fsync,
      (void *) selfie_ftruncate64,
      (void *) selfie_ftruncate,
      (void *) selfie_getc,
      (void *) selfie_open64,
      (void *) selfie_open,
      (void *) selfie_truncate64,
      (void *) selfie_truncate,
      (void *) selfie_ungetc,
      (void *) selfie_ftell,
      (void *) selfie_lseek64,
      (void *) selfie_lseek,
      (void *) selfie_fread,
      (void *) selfie_fwrite,
      (void *) selfie_pread,
      (void *) selfie_preadv,
      (void *) selfie_pwrite,
      (void *) selfie_pwritev,
      (void *) selfie_read,
      (void *) selfie_readv,
      (void *) selfie_write,
      (void *) selfie_writev,
      (void *) selfie_rewind,
      (void *) selfie_fcntl,
      (void *) selfie_ioctl,
      NULL
};

}
