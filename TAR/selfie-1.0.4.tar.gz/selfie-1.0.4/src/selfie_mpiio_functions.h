#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <cstring>
#include <execinfo.h>
#include <dlfcn.h>
#include <cstdarg>
#include <fenv.h>

#pragma STDC FENV_ACCESS ON

typedef void (*function_type)(...);


/// \brief Total number of MPIIO functions
#define N_MPIIO_FUNCTIONS 59

/// \brief Return a string containing name of functions
/// \param[in] i Index
/// \return   Return a string containing name of functions
///
char *selfie_get_mpiio_function_name(int i)
{
   char const *mpiio_functions_name[] = {
      "MPI_File_call_errhandler",
      "MPI_File_close",
      "MPI_File_create_errhandler",
      "MPI_File_delete",
      "MPI_File_get_amode",
      "MPI_File_get_atomicity",
      "MPI_File_get_byte_offset",
      "MPI_File_get_errhandler",
      "MPI_File_get_group",
      "MPI_File_get_info",
      "MPI_File_get_position",
      "MPI_File_get_position_shared",
      "MPI_File_get_size",
      "MPI_File_get_type_extent",
      "MPI_File_get_view",
      "MPI_File_iread_all",
      "MPI_File_iread_at_all",
      "MPI_File_iread_at",
      "MPI_File_iread",
      "MPI_File_iread_shared",
      "MPI_File_iwrite_all",
      "MPI_File_iwrite_at_all",
      "MPI_File_iwrite_at",
      "MPI_File_iwrite",
      "MPI_File_iwrite_shared",
      "MPI_File_open",
      "MPI_File_preallocate",
      "MPI_File_read_all_begin",
      "MPI_File_read_all_end",
      "MPI_File_read_all",
      "MPI_File_read_at_all_begin",
      "MPI_File_read_at_all_end",
      "MPI_File_read_at_all",
      "MPI_File_read_at",
      "MPI_File_read",
      "MPI_File_read_ordered_begin",
      "MPI_File_read_ordered_end",
      "MPI_File_read_ordered",
      "MPI_File_read_shared",
      "MPI_File_seek",
      "MPI_File_seek_shared",
      "MPI_File_set_atomicity",
      "MPI_File_set_errhandler",
      "MPI_File_set_info",
      "MPI_File_set_size",
      "MPI_File_set_view",
      "MPI_File_sync",
      "MPI_File_write_all_begin",
      "MPI_File_write_all_end",
      "MPI_File_write_all",
      "MPI_File_write_at_all_begin",
      "MPI_File_write_at_all_end",
      "MPI_File_write_at_all",
      "MPI_File_write_at",
      "MPI_File_write",
      "MPI_File_write_ordered_begin",
      "MPI_File_write_ordered_end",
      "MPI_File_write_ordered",
      "MPI_File_write_shared",
      "PMPI_File_call_errhandler",
      "PMPI_File_close",
      "PMPI_File_create_errhandler",
      "PMPI_File_delete",
      "PMPI_File_get_amode",
      "PMPI_File_get_atomicity",
      "PMPI_File_get_byte_offset",
      "PMPI_File_get_errhandler",
      "PMPI_File_get_group",
      "PMPI_File_get_info",
      "PMPI_File_get_position",
      "PMPI_File_get_position_shared",
      "PMPI_File_get_size",
      "PMPI_File_get_type_extent",
      "PMPI_File_get_view",
      "PMPI_File_iread_all",
      "PMPI_File_iread_at_all",
      "PMPI_File_iread_at",
      "PMPI_File_iread",
      "PMPI_File_iread_shared",
      "PMPI_File_iwrite_all",
      "PMPI_File_iwrite_at_all",
      "PMPI_File_iwrite_at",
      "PMPI_File_iwrite",
      "PMPI_File_iwrite_shared",
      "PMPI_File_open",
      "PMPI_File_preallocate",
      "PMPI_File_read_all_begin",
      "PMPI_File_read_all_end",
      "PMPI_File_read_all",
      "PMPI_File_read_at_all_begin",
      "PMPI_File_read_at_all_end",
      "PMPI_File_read_at_all",
      "PMPI_File_read_at",
      "PMPI_File_read",
      "PMPI_File_read_ordered_begin",
      "PMPI_File_read_ordered_end",
      "PMPI_File_read_ordered",
      "PMPI_File_read_shared",
      "PMPI_File_seek",
      "PMPI_File_seek_shared",
      "PMPI_File_set_atomicity",
      "PMPI_File_set_errhandler",
      "PMPI_File_set_info",
      "PMPI_File_set_size",
      "PMPI_File_set_view",
      "PMPI_File_sync",
      "PMPI_File_write_all_begin",
      "PMPI_File_write_all_end",
      "PMPI_File_write_all",
      "PMPI_File_write_at_all_begin",
      "PMPI_File_write_at_all_end",
      "PMPI_File_write_at_all",
      "PMPI_File_write_at",
      "PMPI_File_write",
      "PMPI_File_write_ordered_begin",
      "PMPI_File_write_ordered_end",
      "PMPI_File_write_ordered",
      "PMPI_File_write_shared",
      NULL
   };
   return strdup(mpiio_functions_name[i]);
};

/// \brief Array of pointers of functions
function_type selfie_mpiio_orig_pointer_functions[59] = {NULL};

/// \brief Array of pointers of functions
function_type *selfie_mpiio_pointer_functions = selfie_mpiio_orig_pointer_functions;


extern "C" {


#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_call_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_call_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[0];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_call_errhandler");
    }

    selfie_mpiio_global_data[0].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[0].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_call_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_call_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[0];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_call_errhandler");
    }

    selfie_mpiio_global_data[0].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[0].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_close
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_close(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[1];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_close");
    }

    selfie_mpiio_global_data[1].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[1].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_close
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_close(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[1];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_close");
    }

    selfie_mpiio_global_data[1].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[1].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_create_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_create_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[2];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_create_errhandler");
    }

    selfie_mpiio_global_data[2].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[2].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_create_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_create_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[2];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_create_errhandler");
    }

    selfie_mpiio_global_data[2].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[2].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_delete
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_delete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[3];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_delete");
    }

    selfie_mpiio_global_data[3].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[3].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_delete
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_delete(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[3];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_delete");
    }

    selfie_mpiio_global_data[3].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[3].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_amode
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_amode(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[4];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_amode");
    }

    selfie_mpiio_global_data[4].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[4].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_amode
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_amode(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[4];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_amode");
    }

    selfie_mpiio_global_data[4].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[4].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_atomicity
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_atomicity(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[5];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_atomicity");
    }

    selfie_mpiio_global_data[5].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[5].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_atomicity
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_atomicity(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[5];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_atomicity");
    }

    selfie_mpiio_global_data[5].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[5].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_byte_offset
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_byte_offset(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[6];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_byte_offset");
    }

    selfie_mpiio_global_data[6].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[6].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_byte_offset
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_byte_offset(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[6];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_byte_offset");
    }

    selfie_mpiio_global_data[6].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[6].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[7];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_errhandler");
    }

    selfie_mpiio_global_data[7].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[7].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[7];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_errhandler");
    }

    selfie_mpiio_global_data[7].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[7].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_group
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[8];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_group");
    }

    selfie_mpiio_global_data[8].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[8].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_group
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_group(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[8];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_group");
    }

    selfie_mpiio_global_data[8].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[8].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[9];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_info");
    }

    selfie_mpiio_global_data[9].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[9].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[9];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_info");
    }

    selfie_mpiio_global_data[9].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[9].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_position
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_position(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[10];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_position");
    }

    selfie_mpiio_global_data[10].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[10].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_position
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_position(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[10];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_position");
    }

    selfie_mpiio_global_data[10].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[10].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_position_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_position_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[11];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_position_shared");
    }

    selfie_mpiio_global_data[11].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[11].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_position_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_position_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[11];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_position_shared");
    }

    selfie_mpiio_global_data[11].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[11].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[12];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_size");
    }

    selfie_mpiio_global_data[12].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[12].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[12];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_size");
    }

    selfie_mpiio_global_data[12].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[12].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_type_extent
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_type_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[13];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_type_extent");
    }

    selfie_mpiio_global_data[13].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[13].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_type_extent
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_type_extent(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[13];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_type_extent");
    }

    selfie_mpiio_global_data[13].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[13].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_get_view
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_get_view(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[14];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_view");
    }

    selfie_mpiio_global_data[14].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[14].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_get_view
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_get_view(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[14];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_get_view");
    }

    selfie_mpiio_global_data[14].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[14].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iread_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iread_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[15];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_all");
    }

    selfie_mpiio_global_data[15].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[15].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iread_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iread_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[15];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_all");
    }

    selfie_mpiio_global_data[15].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[15].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iread_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iread_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[16];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_at_all");
    }

    selfie_mpiio_global_data[16].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[16].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iread_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iread_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[16];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_at_all");
    }

    selfie_mpiio_global_data[16].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[16].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iread_at
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iread_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[17];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_at");
    }

    selfie_mpiio_global_data[17].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[17].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iread_at
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iread_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[17];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_at");
    }

    selfie_mpiio_global_data[17].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[17].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iread
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iread(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[18];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread");
    }

    selfie_mpiio_global_data[18].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[18].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iread
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iread(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[18];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread");
    }

    selfie_mpiio_global_data[18].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[18].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iread_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iread_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[19];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_shared");
    }

    selfie_mpiio_global_data[19].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[19].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iread_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iread_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[19];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iread_shared");
    }

    selfie_mpiio_global_data[19].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[19].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iwrite_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iwrite_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[20];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_all");
    }

    selfie_mpiio_global_data[20].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[20].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iwrite_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iwrite_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[20];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_all");
    }

    selfie_mpiio_global_data[20].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[20].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iwrite_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iwrite_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[21];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_at_all");
    }

    selfie_mpiio_global_data[21].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[21].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iwrite_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iwrite_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[21];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_at_all");
    }

    selfie_mpiio_global_data[21].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[21].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iwrite_at
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iwrite_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[22];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_at");
    }

    selfie_mpiio_global_data[22].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[22].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iwrite_at
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iwrite_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[22];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_at");
    }

    selfie_mpiio_global_data[22].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[22].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iwrite
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iwrite(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[23];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite");
    }

    selfie_mpiio_global_data[23].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[23].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iwrite
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iwrite(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[23];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite");
    }

    selfie_mpiio_global_data[23].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[23].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_iwrite_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_iwrite_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[24];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_shared");
    }

    selfie_mpiio_global_data[24].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[24].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_iwrite_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_iwrite_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[24];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_iwrite_shared");
    }

    selfie_mpiio_global_data[24].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[24].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_open
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_open(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[25];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_open");
    }

    selfie_mpiio_global_data[25].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[25].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_open
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_open(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[25];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_open");
    }

    selfie_mpiio_global_data[25].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[25].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_preallocate
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_preallocate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[26];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_preallocate");
    }

    selfie_mpiio_global_data[26].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[26].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_preallocate
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_preallocate(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[26];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_preallocate");
    }

    selfie_mpiio_global_data[26].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[26].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[27];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_all_begin");
    }

    selfie_mpiio_global_data[27].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[27].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[27];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_all_begin");
    }

    selfie_mpiio_global_data[27].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[27].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[28];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_all_end");
    }

    selfie_mpiio_global_data[28].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[28].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[28];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_all_end");
    }

    selfie_mpiio_global_data[28].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[28].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[29];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_all");
    }

    selfie_mpiio_global_data[29].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[29].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[29];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_all");
    }

    selfie_mpiio_global_data[29].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[29].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_at_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_at_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[30];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at_all_begin");
    }

    selfie_mpiio_global_data[30].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[30].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_at_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_at_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[30];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at_all_begin");
    }

    selfie_mpiio_global_data[30].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[30].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_at_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_at_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[31];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at_all_end");
    }

    selfie_mpiio_global_data[31].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[31].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_at_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_at_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[31];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at_all_end");
    }

    selfie_mpiio_global_data[31].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[31].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[32];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at_all");
    }

    selfie_mpiio_global_data[32].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[32].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[32];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at_all");
    }

    selfie_mpiio_global_data[32].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[32].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_at
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[33];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at");
    }

    selfie_mpiio_global_data[33].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[33].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_at
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[33];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_at");
    }

    selfie_mpiio_global_data[33].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[33].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[34];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read");
    }

    selfie_mpiio_global_data[34].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[34].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[34];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read");
    }

    selfie_mpiio_global_data[34].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[34].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_ordered_begin
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_ordered_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[35];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_ordered_begin");
    }

    selfie_mpiio_global_data[35].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[35].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_ordered_begin
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_ordered_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[35];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_ordered_begin");
    }

    selfie_mpiio_global_data[35].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[35].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_ordered_end
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_ordered_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[36];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_ordered_end");
    }

    selfie_mpiio_global_data[36].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[36].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_ordered_end
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_ordered_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[36];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_ordered_end");
    }

    selfie_mpiio_global_data[36].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[36].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_ordered
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_ordered(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[37];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_ordered");
    }

    selfie_mpiio_global_data[37].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[37].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_ordered
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_ordered(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[37];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_ordered");
    }

    selfie_mpiio_global_data[37].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[37].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_read_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_read_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[38];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_shared");
    }

    selfie_mpiio_global_data[38].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[38].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_read_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_read_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[38];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_read_shared");
    }

    selfie_mpiio_global_data[38].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[38].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_seek
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_seek(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[39];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_seek");
    }

    selfie_mpiio_global_data[39].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[39].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_seek
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_seek(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[39];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_seek");
    }

    selfie_mpiio_global_data[39].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[39].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_seek_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_seek_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[40];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_seek_shared");
    }

    selfie_mpiio_global_data[40].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[40].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_seek_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_seek_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[40];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_seek_shared");
    }

    selfie_mpiio_global_data[40].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[40].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_set_atomicity
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_set_atomicity(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[41];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_atomicity");
    }

    selfie_mpiio_global_data[41].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[41].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_set_atomicity
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_set_atomicity(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[41];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_atomicity");
    }

    selfie_mpiio_global_data[41].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[41].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_set_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_set_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[42];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_errhandler");
    }

    selfie_mpiio_global_data[42].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[42].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_set_errhandler
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_set_errhandler(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[42];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_errhandler");
    }

    selfie_mpiio_global_data[42].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[42].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_set_info
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_set_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[43];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_info");
    }

    selfie_mpiio_global_data[43].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[43].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_set_info
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_set_info(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[43];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_info");
    }

    selfie_mpiio_global_data[43].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[43].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_set_size
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_set_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[44];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_size");
    }

    selfie_mpiio_global_data[44].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[44].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_set_size
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_set_size(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[44];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_size");
    }

    selfie_mpiio_global_data[44].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[44].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_set_view
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_set_view(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[45];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_view");
    }

    selfie_mpiio_global_data[45].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[45].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_set_view
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_set_view(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[45];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_set_view");
    }

    selfie_mpiio_global_data[45].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[45].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_sync
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_sync(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[46];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_sync");
    }

    selfie_mpiio_global_data[46].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[46].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_sync
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_sync(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[46];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_sync");
    }

    selfie_mpiio_global_data[46].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[46].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[47];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_all_begin");
    }

    selfie_mpiio_global_data[47].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[47].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[47];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_all_begin");
    }

    selfie_mpiio_global_data[47].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[47].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[48];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_all_end");
    }

    selfie_mpiio_global_data[48].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[48].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[48];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_all_end");
    }

    selfie_mpiio_global_data[48].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[48].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[49];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_all");
    }

    selfie_mpiio_global_data[49].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[49].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[49];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_all");
    }

    selfie_mpiio_global_data[49].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[49].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_at_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_at_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[50];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at_all_begin");
    }

    selfie_mpiio_global_data[50].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[50].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_at_all_begin
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_at_all_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[50];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at_all_begin");
    }

    selfie_mpiio_global_data[50].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[50].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_at_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_at_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[51];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at_all_end");
    }

    selfie_mpiio_global_data[51].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[51].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_at_all_end
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_at_all_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[51];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at_all_end");
    }

    selfie_mpiio_global_data[51].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[51].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[52];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at_all");
    }

    selfie_mpiio_global_data[52].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[52].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_at_all
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_at_all(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[52];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at_all");
    }

    selfie_mpiio_global_data[52].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[52].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_at
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[53];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at");
    }

    selfie_mpiio_global_data[53].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[53].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_at
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_at(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[53];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_at");
    }

    selfie_mpiio_global_data[53].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[53].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[54];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write");
    }

    selfie_mpiio_global_data[54].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[54].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[54];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write");
    }

    selfie_mpiio_global_data[54].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[54].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_ordered_begin
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_ordered_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[55];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_ordered_begin");
    }

    selfie_mpiio_global_data[55].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[55].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_ordered_begin
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_ordered_begin(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[55];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_ordered_begin");
    }

    selfie_mpiio_global_data[55].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[55].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_ordered_end
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_ordered_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[56];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_ordered_end");
    }

    selfie_mpiio_global_data[56].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[56].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_ordered_end
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_ordered_end(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[56];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_ordered_end");
    }

    selfie_mpiio_global_data[56].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[56].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_ordered
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_ordered(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[57];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_ordered");
    }

    selfie_mpiio_global_data[57].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[57].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_ordered
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_ordered(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[57];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_ordered");
    }

    selfie_mpiio_global_data[57].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[57].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief MPI_File_write_shared
///
/// \param ...
/// \return int
///
/// \details
///

int MPI_File_write_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[58];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_shared");
    }

    selfie_mpiio_global_data[58].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[58].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

#ifdef __SELFIE_MPI_BUILTIN__
/// \brief PMPI_File_write_shared
///
/// \param ...
/// \return int
///
/// \details
///

int PMPI_File_write_shared(...)
{
    double f_start = 0.0;
    function_type selfie_function = NULL;
    int ap_except = 0;

    selfie_function = selfie_mpiio_pointer_functions[58];

    if(selfie_function == NULL)
    {
       selfie_function = (function_type) dlsym(RTLD_NEXT,"MPI_File_write_shared");
    }

    selfie_mpiio_global_data[58].function_count++;
    f_start = selfie_mysecond();
    ap_except = fedisableexcept(FE_INVALID);
    void* ret = __builtin_apply(selfie_function, 
                                      __builtin_apply_args(), 1024);
    feclearexcept(FE_INVALID);
    feenableexcept(ap_except);
    selfie_mpiio_global_data[58].function_time += selfie_mysecond() - f_start;
    __builtin_return(ret);

};
#endif

}
