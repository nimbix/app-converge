# Bridge Addon for enabling selFIe                                                                        

[Bridge](https://github.com/cea-hpc/bridge)  is a CEA In-House Batch Environment gives a uniform way to access external Batch scheduling systems. 

