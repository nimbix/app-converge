#!/usr/bin/env bash

# rm -rf *~ */*~ \
#    aclocal.m4 \
#    autom4te.cache \
#    depcomp \
#    install-sh \
#    missing \
#    configure \
#    config.h.in \
#    Makefile.in \
#    */Makefile.in \
#    ar-lib \
#    ltmain.sh \
#    compile \
#    m4 \
#    config.guess \
#    config.sub

git clean -f -x -d

